# VetFlow — Sistema de Gestão de Clínica Veterinária

Projeto acadêmico full-stack: API REST em **Node.js + Express + MySQL**
(sem ORM) e SPA em **React 19 + Vite** (sem UI kit externo), unificados
num único repositório.

Este README, sozinho, é suficiente para configurar e rodar o projeto do
zero. Os READMEs dentro de `backend/` e `frontend/` detalham cada parte
individualmente (endpoints, decisões de arquitetura específicas etc.).

---

## 1. Visão geral

- **Backend** (`backend/`): API REST com `mysql2/promise` (pool de
  conexões, SQL puro parametrizado), autenticação JWT + bcrypt,
  autorização por `tipo_usuario` (`admin`, `recepcionista`,
  `veterinario`, `cliente`), transações com `FOR UPDATE` no controle de
  estoque de remédio e no lançamento de caixa.
- **Frontend** (`frontend/`): SPA com `react-router-dom`, estado local +
  `AuthContext` (sem Redux/Zustand), CSS próprio com design tokens, CRUD
  genérico compartilhado (`PaginaCrudGenerica.jsx`) que espelha o
  `crudGenerico.js` do backend.
- **Banco**: MySQL. O schema completo está em `database/schema.sql`.

## 2. Arquitetura — estrutura de pastas

```
vetflow/
├── README.md                  # este arquivo
├── .gitignore
├── package.json                # orquestra backend + frontend a partir da raiz
├── docker-compose.yml          # opcional — sobe só o MySQL
├── database/
│   ├── schema.sql               # DDL completo (tabelas, FKs, índices)
│   └── seed.sql                 # dados de exemplo (clientes, animais, veterinários...)
├── backend/
│   ├── .env.example
│   ├── package.json
│   ├── server.js                 # bootstrap Express + checagem de conexão com o banco
│   ├── config/db.js              # pool mysql2/promise
│   ├── controllers/              # regras de negócio + queries SQL
│   ├── middleware/auth.js        # autenticar (JWT) + autorizar (por tipo_usuario)
│   ├── routes/                   # mapeamento rota -> controller -> permissões
│   ├── scripts/seedAdmin.js      # cria/atualiza o primeiro usuário admin
│   └── README.md
└── frontend/
    ├── .env.example
    ├── package.json
    ├── vite.config.js
    ├── index.html
    ├── public/
    ├── src/
    │   ├── api/client.js         # wrapper de fetch + JWT + tratamento de sessão expirada
    │   ├── context/AuthContext.jsx
    │   ├── components/
    │   └── pages/
    └── README.md
```

## 3. Pré-requisitos

- **Node.js** 18+ e npm
- **MySQL** 8+ rodando localmente (ou via Docker — ver seção 5.2)

## 4. Setup — passo a passo

### 4.1 Clonar e instalar dependências

```bash
git clone <url-do-repositorio> vetflow
cd vetflow
npm run install:all
```

Isso instala as dependências de `backend/` e `frontend/` (e, se quiser
usar `npm run dev` na raiz, rode `npm install` na raiz também, uma vez,
pra baixar o `concurrently`).

```bash
npm install
```

### 4.2 Banco de dados

Crie o banco (nome sugerido: `vetflow`, mas pode ser outro — só mantenha
consistente com o `.env` do backend):

```sql
CREATE DATABASE vetflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Rode o schema e, opcionalmente, os dados de exemplo:

```bash
mysql -u root -p vetflow < database/schema.sql
mysql -u root -p vetflow < database/seed.sql   # opcional, dados de demonstração
```

### 4.3 Variáveis de ambiente

Este projeto já vem com `backend/.env` e `frontend/.env` preenchidos com
valores padrão de desenvolvimento (o `.env.example` continua servindo de
referência/documentação). Os defaults do `backend/.env` já batem com as
credenciais do `docker-compose.yml` da raiz (seção 5.2) — se você for usar
Docker para o MySQL, não precisa editar nada.

Se for usar um MySQL **local** (sem Docker) em vez do container, ajuste
`backend/.env` com as credenciais do seu MySQL:

```bash
# se preferir recomeçar do zero:
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

Edite `backend/.env` com as credenciais do seu MySQL local e, se for expor
o projeto além do seu computador, troque `JWT_SECRET` por um valor próprio.
`frontend/.env` já vem com `VITE_API_URL` apontando pra
`http://localhost:3000`, coerente com o `PORT` padrão do backend — só
ajuste se mudar a porta.

⚠️ **Gotcha comum no Linux/Debian/Ubuntu**: por padrão, o usuário `root`
do MySQL usa o plugin `auth_socket`, que **não aceita login por senha via
TCP** (exatamente o que o `mysql2`/Node precisa). Se `backend/.env` usa
`DB_USER=root` e o backend não conseguir conectar mesmo com a senha
certa, rode isto no MySQL pra trocar pro plugin de senha padrão (ou crie
um usuário dedicado, como no `docker-compose.yml`):

```sql
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'sua_senha';
FLUSH PRIVILEGES;
```

### 4.4 Criar o primeiro usuário admin

A tela pública de Cadastro (`/cadastro` no frontend) só cria usuários tipo
`cliente` — por segurança, `POST /auth/registrar` sempre ignora qualquer
`tipo_usuario` enviado na requisição e força `cliente` (ver
`backend/controllers/authController.js`). Papéis `admin`,
`recepcionista` e `veterinario` continuam sendo criados só internamente.
Pra ter o primeiro usuário admin, escolha uma opção:

**Opção A — script Node (recomendado):**
```bash
cd backend
npm run seed:admin
# ou com dados customizados:
npm run seed:admin -- "Seu Nome" seu@email.com suaSenha123
```
Sem argumentos, cria (ou reseta a senha de) `admin@vetflow.com` /
`admin123` — troque essa senha assim que possível fora de
demonstração/dev local.

> Note que `POST /auth/registrar` (usado pela tela pública de Cadastro)
> **não** serve mais pra criar admin — o endpoint sempre força
> `tipo_usuario: 'cliente'` por segurança, mesmo que outro valor seja
> enviado no corpo da requisição. Use sempre `seedAdmin.js` acima.

### 4.5 Subir o projeto

```bash
npm run dev
```

Sobe backend (`nodemon`, porta `3000`) e frontend (`vite`, porta `5173`)
juntos, em paralelo. Acesse `http://localhost:5173` e logue com o usuário
criado no passo 4.4.

## 5. Modos de execução

### 5.1 Desenvolvimento (padrão)

`npm run dev` na raiz — dois processos separados (API em `:3000`, Vite em
`:5173`). O frontend chama a API pela URL absoluta em `VITE_API_URL`; não
há proxy configurado no `vite.config.js`, o CORS do backend (`cors()`,
sem restrição de origem) já resolve isso — decisão que preserva a
abordagem original dos dois projetos (ver `frontend/README.md`).

### 5.2 Banco via Docker (opcional, recomendado se você não quer instalar MySQL)

Se preferir não instalar MySQL localmente:

```bash
docker compose up -d
# espere ficar "healthy":
docker compose ps
```

Isso sobe um MySQL 8 já com `database/schema.sql` e `database/seed.sql`
carregados, e já cria um usuário dedicado `vetflow`/`vetflow_password`
(sem precisar de `root`). O `backend/.env` já shippado com o projeto **já
está configurado pra essas credenciais** — não precisa editar nada:
```
DB_HOST=localhost
DB_PORT=3306
DB_USER=vetflow
DB_PASSWORD=vetflow_password
DB_NAME=vetflow
```
Docker é só pra essa parte — backend e frontend continuam rodando com
`npm run dev` normalmente, sem Docker. Não é obrigatório: com um MySQL
local já instalado, pule esta seção (mas troque as credenciais em
`backend/.env` pelas do seu MySQL — ver gotcha do `auth_socket` na
seção 4.3 se for usar `root`).

### 5.3 Produção (processo único)

```bash
npm run build   # gera frontend/dist
npm start       # build do frontend + sobe o backend em modo produção
```

Em `NODE_ENV=production`, o Express (`backend/server.js`) passa a servir
os arquivos estáticos de `frontend/dist` e faz fallback de rota pro
`index.html` (necessário pro roteamento do `react-router-dom` funcionar
em URLs acessadas diretamente, tipo `/consultas/3`). Tudo num único
processo e porta (a do backend, `PORT` no `.env`).

## 6. Fluxo de teste manual sugerido

1. Logue com o usuário admin.
2. Cadastre um **cliente**.
3. Cadastre um **animal**, vinculado a esse cliente.
4. Cadastre um **veterinário** (e, opcionalmente, vincule uma
   **especialidade** a ele).
5. Cadastre um **remédio** com estoque inicial.
6. **Agende uma consulta** para o animal com o veterinário.
7. Abra a consulta, mude o status pra `em_andamento`.
8. **Prescreva o remédio** cadastrado — repare que o estoque é decrementado
   automaticamente (transação com `FOR UPDATE`).
9. Conclua a consulta (status `concluida`), registrando diagnóstico e valor.
10. **Abra um caixa**.
11. Registre o **pagamento** da consulta como `pago`, vinculado ao caixa
    aberto — repare que uma movimentação de entrada é lançada automaticamente.
12. Feche o caixa e confira a diferença calculada entre o valor esperado e
    o informado.

## 7. Endpoints principais

| Método | Rota | Descrição |
|---|---|---|
| POST | `/auth/registrar` | Cria usuário de login (pública) |
| POST | `/auth/login` | Login, retorna JWT (pública) |
| GET/POST/PUT/DELETE | `/clientes` | CRUD de clientes |
| GET/POST/PUT/DELETE | `/animais` | CRUD de animais |
| GET | `/animais/:id/consultas` | Histórico clínico do animal |
| GET/POST/PUT/DELETE | `/veterinarios` | CRUD de veterinários |
| GET/POST/DELETE | `/veterinarios/:id/especialidades` | Vincula/remove especialidade |
| GET/POST/PUT/DELETE | `/especialidades` | CRUD de especialidades |
| GET/POST/PUT/DELETE | `/remedios` | CRUD de remédios |
| GET/POST/PUT | `/consultas` | Agendar e editar consultas |
| PATCH | `/consultas/:id/status` | Muda status, registra diagnóstico/valor |
| DELETE | `/consultas/:id` | Exclui consulta (só admin) |
| POST | `/prescricoes` | Prescreve remédio (dá baixa automática no estoque) |
| DELETE | `/prescricoes/:id` | Cancela prescrição (devolve ao estoque) |
| GET | `/prescricoes/consulta/:idConsulta` | Remédios prescritos numa consulta |
| GET/POST/PATCH | `/caixas` | Lista, abre, busca e fecha caixa |
| POST | `/caixas/abrir` | Abre caixa do dia |
| PATCH | `/caixas/:id/fechar` | Fecha caixa, calcula diferença |
| POST | `/caixas/:id/movimentacao` | Lançamento manual (entrada/saída) |
| GET/POST | `/pagamentos` | Lista e registra pagamento de consulta |
| PATCH | `/pagamentos/:id/status` | Muda status (lança no caixa se virar "pago") |

## 8. Matriz de permissões por `tipo_usuario`

Toda rota (exceto `/auth/*`) exige `Authorization: Bearer <token>`. O que
cada papel pode fazer, por recurso:

| Recurso | Leitura | Escrita (criar/editar/excluir) |
|---|---|---|
| `/clientes`, `/animais`, `/remedios` | qualquer autenticado | admin, recepcionista |
| `/veterinarios`, `/especialidades`, vínculo vet↔especialidade | qualquer autenticado | admin |
| `/consultas` (agendar/editar dados administrativos) | qualquer autenticado | admin, recepcionista |
| `/consultas/:id/status` (status/diagnóstico) | — | admin, veterinario |
| `/consultas/:id` (excluir) | — | admin |
| `/prescricoes` (criar/cancelar) | qualquer autenticado (leitura) | admin, veterinario |
| `/caixas`, `/pagamentos` | admin, recepcionista | admin, recepcionista |

## 9. Decisões de arquitetura preservadas

- **Sem ORM**: SQL puro com `mysql2/promise`, queries parametrizadas.
- **Sem Redux/Zustand** no frontend: estado local + `AuthContext`.
- **CRUD genérico compartilhado** (backend `crudGenerico.js` e frontend
  `PaginaCrudGenerica.jsx`) para as entidades sem regra de negócio
  especial (cliente, veterinário, especialidade, remédio).
- **Whitelist de campos** em todo INSERT/UPDATE — nunca `req.body` cru.
- **Transações + `FOR UPDATE`** na prescrição de remédio (baixa de
  estoque) e no pagamento (lançamento automático no caixa).
- **Controle de acesso por `tipo_usuario`**, reforçado no backend — os
  botões que somem na UI são só UX, a autorização real está nas rotas.

Ver `database/schema.sql` para o raciocínio completo por trás de cada
tipo de coluna, constraint única e regra de `ON DELETE` (CASCADE vs.
RESTRICT vs. SET NULL) — cada decisão de FK está comentada linha a linha
no próprio arquivo, junto com o trade-off quando havia mais de uma opção
razoável.

## 10. Aprimoramentos implementados na unificação

- Verificação de conexão com o banco na subida do servidor (`server.js`).
- Log de requisições em desenvolvimento (`morgan`).
- Rate limiting em `/auth/login` e `/auth/registrar` (`express-rate-limit`).
- Tratamento de sessão expirada no frontend (401/403 → limpa
  `localStorage` e redireciona pro login com mensagem clara).
- Mensagens de erro mais claras no frontend quando o backend está
  indisponível (falha de rede no `fetch`).
- Serving do frontend buildado pelo próprio backend em produção
  (`express.static` + fallback de rota).
- `database/schema.sql` e `database/seed.sql` (lacuna que impedia o
  projeto de rodar).
- `backend/.env.example` (lacuna que impedia o projeto de rodar).
- `backend/scripts/seedAdmin.js` para criar o primeiro usuário admin sem
  precisar de UI de cadastro.

### 10.1 Segunda rodada de aprimoramentos (pedido explícito, após a unificação)

- **Tela pública de Cadastro** (`frontend/src/pages/Cadastro.jsx`, rota
  `/cadastro`): formulário de nome/email/senha/confirmação, no mesmo
  padrão visual do Login, com link cruzado entre as duas telas.
- **Correção de segurança em `POST /auth/registrar`**: antes, o endpoint
  aceitava `tipo_usuario` vindo do corpo da requisição — qualquer um
  podia se autopromover a `admin` via curl/Postman, sem passar pela UI.
  Agora o endpoint público **sempre** cria o usuário como `cliente`,
  ignorando qualquer valor enviado. Papéis administrativos continuam só
  via `seedAdmin.js` ou edição direta no banco.
- **Busca client-side** nas listagens genéricas (`PaginaCrudGenerica.jsx`)
  — filtra os registros já carregados, sem exigir endpoint novo no
  backend.
- **Validação de formato de CPF** no formulário de Clientes (`pattern`
  HTML `000.000.000-00`).
- **`backend/.env` e `frontend/.env` já preenchidos** com valores padrão
  de desenvolvimento (compatíveis com `docker-compose.yml`), pra reduzir
  passos de setup manual — ver seção 4.3.

### O que foi avaliado e deliberadamente deixado de fora

- **Tela de cadastro de usuário via UI**: implementada depois (ver seção
  10.1) — só ficou de fora nessa primeira rodada de unificação porque o
  escopo mínimo pra "rodar fim a fim" não exigia; virou um pedido
  explícito em seguida.
- **Paginação nas listagens** (diferente de busca/filtro, que já existe —
  ver seção 10.1): documentado como fora de escopo nos READMEs originais;
  mantido assim — o volume de dados de um projeto acadêmico não justifica
  a complexidade extra de paginar via backend.
- **Refresh token**: o JWT expira em 8h e exige novo login; o frontend já
  trata isso de forma amigável (aprimoramento acima), o que resolve a
  parte que mais afetava a experiência de uso sem precisar do mecanismo
  completo de refresh.

## 11. O que continua fora de escopo (herdado dos projetos originais)

- Snapshot de preço em `consulta_remedio` (preço do remédio no momento da
  prescrição não é persistido, só devolvido na resposta da criação).
- Hospitalização/internação.

## 12. Troubleshooting rápido

- **"Não foi possível conectar ao servidor" em TUDO (login, cadastro,
  qualquer tela) — mesmo com usuário/senha certos**: isso é uma falha de
  rede no `fetch` do frontend (`src/api/client.js`), não um erro de
  aplicação — se fosse erro de credencial, você veria uma mensagem tipo
  "Credenciais inválidas", vinda do backend. Esse sintoma específico
  quase sempre significa que **o processo do backend nem chegou a subir**.
  Passos, em ordem:
  1. Olhe o terminal onde rodou `npm run dev` (ou `node backend/server.js`)
     — se aparecer `Não foi possível conectar ao MySQL...`, o backend
     falhou ao conectar no banco e **saiu antes de começar a escutar na
     porta 3000** (`server.js` faz isso de propósito, pra falhar rápido
     em vez de aceitar requisições que vão quebrar). Resolva a conexão
     com o MySQL primeiro (itens abaixo) — o resto se resolve sozinho.
  2. Confirme que o MySQL está de pé: `mysql -u root -p` (local) ou
     `docker compose ps` (Docker) deve mostrar `healthy`.
  3. Confirme que o banco `vetflow` existe e tem as tabelas
     (`mysql -u root -p -e "USE vetflow; SHOW TABLES;"`) — se estiver
     vazio, rode `database/schema.sql` (seção 4.2).
  4. Confirme que `backend/.env` tem host/porta/usuário/senha/nome do
     banco batendo com o MySQL que você está usando (local ou Docker —
     ver seção 4.3). Usuário/senha errados também impedem o backend de
     subir, com o mesmo sintoma no frontend.
- **Backend não sobe / erro de conexão com o banco**: confira
  `backend/.env` (host, porta, usuário, senha, nome do banco) e se o
  MySQL está mesmo de pé (`mysql -u root -p` deve conectar). No
  Linux/Debian/Ubuntu, veja o gotcha do `auth_socket` na seção 4.3 se
  estiver usando `DB_USER=root`.
- **Login falha mesmo com o schema rodado**: confirme que criou o usuário
  admin (seção 4.4) — o schema por si só não cria nenhum usuário.
- **Frontend carrega mas todas as chamadas falham**: confira se
  `VITE_API_URL` no `frontend/.env` aponta pra porta certa do backend.
- **Porta em uso ao rodar `npm run dev`**: o backend usa `3000` e o
  frontend `5173` por padrão — libere essas portas ou ajuste `PORT` (no
  `backend/.env`) e `VITE_API_URL` (no `frontend/.env`) em conjunto.
