-- =============================================================================
-- VetFlow — Dados de exemplo (opcional)
-- =============================================================================
-- Este arquivo popula algumas entidades simples para facilitar a demonstração
-- do sistema (apresentação/defesa), sem duplicar a criação do usuário admin.
--
-- IMPORTANTE: rode database/schema.sql primeiro. Depois, para criar o
-- primeiro usuário admin, use UMA das opções abaixo (ver README da raiz):
--   1) node scripts/seedAdmin.js               (dentro de backend/, recomendado)
--   2) POST /auth/registrar via curl/Postman
--
-- Uso:
--   USE vetflow;
--   SOURCE database/seed.sql;
-- =============================================================================

SET NAMES utf8mb4;

INSERT INTO especialidade (nome, descricao) VALUES
  ('Clínica Geral', 'Atendimento clínico de rotina e check-ups'),
  ('Cirurgia', 'Procedimentos cirúrgicos de pequeno e médio porte'),
  ('Dermatologia', 'Doenças de pele, pelagem e alergias'),
  ('Odontologia', 'Saúde bucal e procedimentos odontológicos');

INSERT INTO veterinario (nome, crmv, telefone, email, data_contratacao) VALUES
  ('Dra. Marina Souza', 'CRMV-SP 12345', '(11) 98888-1010', 'marina.souza@vetflow.com', '2022-03-01'),
  ('Dr. Rafael Lima', 'CRMV-SP 54321', '(11) 98888-2020', 'rafael.lima@vetflow.com', '2023-07-15');

INSERT INTO veterinario_especialidade (id_veterinario, id_especialidade) VALUES
  (1, 1), (1, 3),
  (2, 1), (2, 2);

INSERT INTO cliente (nome, cpf, telefone, email, endereco) VALUES
  ('Ana Paula Ferreira', '111.111.111-11', '(11) 97777-1111', 'ana.ferreira@example.com', 'Rua das Palmeiras, 100 - São Paulo/SP'),
  ('Carlos Eduardo Santos', '222.222.222-22', '(11) 97777-2222', 'carlos.santos@example.com', 'Av. Brasil, 500 - São Paulo/SP'),
  ('Juliana Costa', '333.333.333-33', '(11) 97777-3333', 'juliana.costa@example.com', 'Rua dos Ipês, 45 - São Paulo/SP');

INSERT INTO animal (nome, especie, raca, data_nascimento, sexo, peso, id_cliente) VALUES
  ('Rex', 'Cão', 'Labrador', '2020-05-10', 'M', 28.50, 1),
  ('Mimi', 'Gato', 'Siamês', '2021-09-22', 'F', 4.20, 1),
  ('Thor', 'Cão', 'Bulldog Francês', '2019-01-30', 'M', 12.00, 2),
  ('Luna', 'Gato', 'SRD', '2022-02-14', 'F', 3.80, 3);

INSERT INTO remedio (nome, fabricante, principio_ativo, forma_farmaceutica, preco_unitario, estoque) VALUES
  ('Amoxicilina Pet 250mg', 'VetPharma', 'Amoxicilina', 'comprimido', 12.50, 120),
  ('Antipulgas VetLine', 'VetLine', 'Fipronil', 'pipeta', 45.90, 60),
  ('Anti-inflamatório Vetprofeno', 'VetPharma', 'Cetoprofeno', 'comprimido', 18.30, 80),
  ('Vermífugo Total Pet', 'AgroVet', 'Praziquantel + Pamoato de Pirantel', 'comprimido', 22.00, 100);

-- Consultas, prescrições, caixa e pagamentos ficam de fora do seed de propósito:
-- envolvem regras de negócio com transação (baixa de estoque, lançamento
-- automático no caixa) que fazem mais sentido sendo criadas pela própria UI,
-- seguindo o fluxo de teste descrito no README da raiz (cliente -> animal ->
-- veterinário -> consulta -> prescrição -> caixa -> pagamento).
