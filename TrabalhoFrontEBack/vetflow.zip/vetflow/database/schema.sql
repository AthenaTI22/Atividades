-- =============================================================================
-- VetFlow — Schema do banco de dados (MySQL 8+)
-- =============================================================================
-- Este arquivo foi reconstruído lendo TODAS as queries SQL presentes em
-- backend/controllers/*.js (SELECT, INSERT, UPDATE, DELETE) — é a peça que
-- faltava para o projeto rodar fim a fim. Nomes de tabela/coluna, tipos e
-- constraints foram validados coluna a coluna contra o código real, não
-- apenas contra o levantamento de engenharia reversa do prompt original.
--
-- ESCOLHA DE SCHEMA DEFINITIVO (auditoria feita antes de qualquer alteração
-- de código, ver instrucoes.txt):
-- Além deste arquivo, foi encontrado um segundo dump SQL avulso
-- ("banco_de_dados.sql", banco `clinica_veterinaria`) descrevendo as mesmas
-- 12 entidades. Os dois foram comparados coluna a coluna contra as queries
-- reais de backend/controllers/*.js, e ESTE arquivo (database/schema.sql,
-- banco `vetflow`) foi escolhido como fonte única de verdade, pelos motivos:
--   1. Nome do banco: `vetflow` é o único nome usado em todo o resto do
--      projeto (backend/.env.example DB_NAME, docker-compose.yml
--      MYSQL_DATABASE, README raiz) — `clinica_veterinaria` exigiria
--      reescrever esses arquivos sem nenhum ganho.
--   2. `pagamento.forma_pagamento`: o dump avulso declara um ENUM fixo, mas
--      pagamentoController.criar() nunca valida forma_pagamento contra uma
--      lista — só repassa o que o front envia. Um ENUM ali rejeitaria (erro
--      500 não tratado) qualquer valor fora da lista que o front venha a
--      enviar no futuro; VARCHAR(30) (como já estava neste arquivo) é o que
--      realmente corresponde ao comportamento do código.
--   3. `consulta.valor`: aqui é NULL sem DEFAULT problemático, coerente com
--      consultaController.criar(), que nunca envia `valor` no INSERT.
--   4. `animal.id_cliente`: aqui é ON DELETE RESTRICT, coerente com
--      crudGenerico.deletar() tratando ER_ROW_IS_REFERENCED_2 (409) para
--      cliente; o dump avulso usa CASCADE, o que apagaria o histórico de
--      animais/consultas/prescrições de um cliente inteiro numa única
--      exclusão sem aviso — divergente do comportamento que o
--      crudGenerico genérico foi escrito para tratar.
--   5. `usuario.senha`: aqui é VARCHAR(60), dimensionado para o tamanho
--      fixo de um hash bcrypt (o que authController usa via bcryptjs);
--      o dump avulso usa VARCHAR(255), que também funcionaria, mas o
--      valor aqui documenta a intenção real do dado armazenado.
-- O arquivo "banco_de_dados.sql" enviado foi tratado apenas como referência
-- de comparação nesta auditoria e não é usado em nenhuma outra parte do
-- projeto.
--
-- Convenções adotadas:
--   - InnoDB (suporte a transações e FKs, exigido pelas rotinas de estoque
--     de remédio e caixa que usam beginTransaction/commit/rollback).
--   - utf8mb4 (acentuação em pt-BR sem surpresas).
--   - Chaves primárias INT UNSIGNED AUTO_INCREMENT.
--   - DATETIME (não TIMESTAMP) nas colunas de data/hora — combina com
--     `dateStrings: true` configurado no pool em backend/config/db.js, que
--     deliberadamente evita conversões de timezone entre o driver e o app.
--
-- Como usar:
--   1. Crie o banco (veja o README.md da raiz para o passo a passo completo):
--        CREATE DATABASE vetflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
--   2. Selecione o banco e rode este arquivo inteiro:
--        USE vetflow;
--        SOURCE database/schema.sql;
--   3. Rode database/seed.sql para ter um usuário admin e dados de exemplo.
-- =============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Ordem de DROP é o inverso da ordem de dependência, para permitir re-rodar
-- este script em um banco já existente sem erros de FK.
DROP TABLE IF EXISTS movimentacao_caixa;
DROP TABLE IF EXISTS pagamento;
DROP TABLE IF EXISTS consulta_remedio;
DROP TABLE IF EXISTS consulta;
DROP TABLE IF EXISTS veterinario_especialidade;
DROP TABLE IF EXISTS caixa;
DROP TABLE IF EXISTS remedio;
DROP TABLE IF EXISTS especialidade;
DROP TABLE IF EXISTS veterinario;
DROP TABLE IF EXISTS animal;
DROP TABLE IF EXISTS usuario;
DROP TABLE IF EXISTS cliente;

SET FOREIGN_KEY_CHECKS = 1;

-- -----------------------------------------------------------------------------
-- cliente
-- -----------------------------------------------------------------------------
-- Dono(s) do(s) animal(is). CPF e email únicos: o crudGenerico.criar() trata
-- genericamente o erro ER_DUP_ENTRY (409) para qualquer entidade — CPF e
-- email são os candidatos naturais a chave única aqui.
CREATE TABLE cliente (
  id_cliente     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome           VARCHAR(150) NOT NULL,
  cpf            VARCHAR(20)  NOT NULL,
  telefone       VARCHAR(20)  NULL,
  email          VARCHAR(150) NULL,
  endereco       VARCHAR(255) NULL,
  PRIMARY KEY (id_cliente),
  UNIQUE KEY uk_cliente_cpf (cpf),
  UNIQUE KEY uk_cliente_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- veterinario
-- -----------------------------------------------------------------------------
-- CRMV é o registro profissional — único por natureza (e o crudGenerico
-- trata ER_DUP_ENTRY caso duas cadastros usem o mesmo).
CREATE TABLE veterinario (
  id_veterinario    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome              VARCHAR(150) NOT NULL,
  crmv              VARCHAR(20)  NOT NULL,
  telefone          VARCHAR(20)  NULL,
  email             VARCHAR(150) NULL,
  data_contratacao  DATE         NULL,
  PRIMARY KEY (id_veterinario),
  UNIQUE KEY uk_veterinario_crmv (crmv),
  UNIQUE KEY uk_veterinario_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- especialidade
-- -----------------------------------------------------------------------------
CREATE TABLE especialidade (
  id_especialidade  INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome              VARCHAR(100) NOT NULL,
  descricao         TEXT         NULL,
  PRIMARY KEY (id_especialidade),
  UNIQUE KEY uk_especialidade_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- veterinario_especialidade (associativa N:N)
-- -----------------------------------------------------------------------------
-- Chave primária composta (id_veterinario, id_especialidade) já garante a
-- unicidade tratada em veterinarioEspecialidadeController.vincular() via
-- ER_DUP_ENTRY, sem precisar de uma UNIQUE KEY redundante.
--
-- Trade-off de ON DELETE (documentado, ver seção 4 das instruções): como é
-- uma tabela puramente associativa, sem significado próprio fora do vínculo,
-- usamos CASCADE nas duas FKs — excluir um veterinário ou uma especialidade
-- remove só o vínculo, sem impedir a exclusão por causa de uma associação
-- secundária. Isso é diferente da regra de veterinario <-> consulta (essa
-- sim é RESTRICT, ver tabela `consulta` abaixo), que protege histórico
-- clínico de verdade.
CREATE TABLE veterinario_especialidade (
  id_veterinario    INT UNSIGNED NOT NULL,
  id_especialidade  INT UNSIGNED NOT NULL,
  PRIMARY KEY (id_veterinario, id_especialidade),
  CONSTRAINT fk_ve_veterinario FOREIGN KEY (id_veterinario)
    REFERENCES veterinario (id_veterinario) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_ve_especialidade FOREIGN KEY (id_especialidade)
    REFERENCES especialidade (id_especialidade) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- usuario
-- -----------------------------------------------------------------------------
-- Login do sistema. id_cliente/id_veterinario são opcionais (autoRegistro
-- pode ser feito sem vínculo, ex: recepcionista/admin). Se o cliente ou
-- veterinário vinculado for excluído, o login sobrevive (SET NULL) — só o
-- vínculo se perde, e o acesso do usuário continua funcionando conforme seu
-- tipo_usuario.
CREATE TABLE usuario (
  id_usuario      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome            VARCHAR(150) NOT NULL,
  email           VARCHAR(150) NOT NULL,
  senha           VARCHAR(60)  NOT NULL COMMENT 'hash bcrypt',
  tipo_usuario    ENUM('admin', 'recepcionista', 'veterinario', 'cliente') NOT NULL DEFAULT 'cliente',
  id_cliente      INT UNSIGNED NULL,
  id_veterinario  INT UNSIGNED NULL,
  ultimo_login    DATETIME NULL,
  PRIMARY KEY (id_usuario),
  UNIQUE KEY uk_usuario_email (email),
  KEY idx_usuario_cliente (id_cliente),
  KEY idx_usuario_veterinario (id_veterinario),
  CONSTRAINT fk_usuario_cliente FOREIGN KEY (id_cliente)
    REFERENCES cliente (id_cliente) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_usuario_veterinario FOREIGN KEY (id_veterinario)
    REFERENCES veterinario (id_veterinario) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- animal
-- -----------------------------------------------------------------------------
-- id_cliente com ON DELETE RESTRICT (padrão do MySQL/InnoDB): não deixa
-- apagar um cliente que ainda tem animais cadastrados — o crudGenerico.deletar()
-- do cliente já trata ER_ROW_IS_REFERENCED_2 genericamente pra esse caso.
CREATE TABLE animal (
  id_animal         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome              VARCHAR(100) NOT NULL,
  especie           VARCHAR(60)  NOT NULL,
  raca              VARCHAR(60)  NULL,
  data_nascimento   DATE         NULL,
  sexo              ENUM('M', 'F') NULL,
  peso              DECIMAL(6,2) NULL COMMENT 'em kg',
  id_cliente        INT UNSIGNED NOT NULL,
  PRIMARY KEY (id_animal),
  KEY idx_animal_cliente (id_cliente),
  CONSTRAINT fk_animal_cliente FOREIGN KEY (id_cliente)
    REFERENCES cliente (id_cliente) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- remedio
-- -----------------------------------------------------------------------------
-- `estoque` é a ÚNICA fonte de verdade sobre quantidade disponível — só é
-- alterado via a transação de prescrição/cancelamento em
-- consultaRemedioController.js (ver comentário lá).
CREATE TABLE remedio (
  id_remedio            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome                  VARCHAR(150) NOT NULL,
  fabricante            VARCHAR(150) NULL,
  principio_ativo       VARCHAR(150) NULL,
  forma_farmaceutica    VARCHAR(60)  NULL,
  preco_unitario        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  estoque               INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id_remedio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- caixa
-- -----------------------------------------------------------------------------
-- Regra "só um caixa aberto por vez" é aplicada na camada de aplicação
-- (caixaController.abrir), não há índice único parcial pra isso porque o
-- MySQL não suporta índice único condicional nativamente sem gambiarra
-- (ex: coluna gerada). Manter a checagem na aplicação é mais simples e
-- é exatamente o nível de complexidade que o projeto pede.
CREATE TABLE caixa (
  id_caixa                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  data_abertura           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  valor_abertura          DECIMAL(10,2) NOT NULL,
  responsavel_abertura    VARCHAR(150) NOT NULL,
  status                  ENUM('aberto', 'fechado') NOT NULL DEFAULT 'aberto',
  observacoes             TEXT NULL,
  data_fechamento         DATETIME NULL,
  valor_fechamento        DECIMAL(10,2) NULL,
  responsavel_fechamento  VARCHAR(150) NULL,
  PRIMARY KEY (id_caixa),
  KEY idx_caixa_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- consulta
-- -----------------------------------------------------------------------------
-- id_animal: ON DELETE CASCADE — comentário explícito em animalController.js
-- ("aqui id_animal é PAI de consulta (CASCADE), então apagar o animal apaga
-- o histórico de consultas dele").
-- id_veterinario: ON DELETE RESTRICT — comentado no prompt original e
-- coerente com o crudGenerico.deletar() do veterinário tratando
-- ER_ROW_IS_REFERENCED_2 (409) quando há consultas vinculadas.
CREATE TABLE consulta (
  id_consulta     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_animal       INT UNSIGNED NOT NULL,
  id_veterinario  INT UNSIGNED NOT NULL,
  data_hora       DATETIME NOT NULL,
  motivo          TEXT NULL,
  status          ENUM('agendada', 'em_andamento', 'concluida', 'cancelada') NOT NULL DEFAULT 'agendada',
  diagnostico     TEXT NULL,
  observacoes     TEXT NULL,
  valor           DECIMAL(10,2) NULL,
  PRIMARY KEY (id_consulta),
  KEY idx_consulta_animal (id_animal),
  KEY idx_consulta_veterinario (id_veterinario),
  KEY idx_consulta_data_hora (data_hora),
  KEY idx_consulta_status (status),
  CONSTRAINT fk_consulta_animal FOREIGN KEY (id_animal)
    REFERENCES animal (id_animal) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_consulta_veterinario FOREIGN KEY (id_veterinario)
    REFERENCES veterinario (id_veterinario) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- consulta_remedio (prescrição)
-- -----------------------------------------------------------------------------
-- id_consulta: ON DELETE CASCADE — trade-off documentado: excluir uma
-- consulta (ação restrita a admin, ver consultaRoutes.js) é uma operação
-- rara e administrativa; sem CASCADE aqui, essa exclusão quebraria com um
-- erro 500 não tratado (consultaController.deletar() não trata
-- ER_ROW_IS_REFERENCED_2 como o crudGenerico faz). NOTA: o CASCADE do
-- banco NÃO devolve a quantidade ao estoque de remedio — só o endpoint
-- DELETE /prescricoes/:id faz isso, dentro de uma transação. Ou seja,
-- excluir uma consulta com prescrições ativas via DELETE /consultas/:id
-- decrementa o histórico sem repor estoque. Isso é aceitável pro escopo
-- acadêmico do projeto, mas fica documentado aqui como limitação conhecida.
-- id_remedio: ON DELETE RESTRICT — protege o histórico de prescrições:
-- não deixa apagar um remédio que já foi prescrito alguma vez.
CREATE TABLE consulta_remedio (
  id_consulta_remedio   INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_consulta           INT UNSIGNED NOT NULL,
  id_remedio            INT UNSIGNED NOT NULL,
  dosagem               VARCHAR(100) NULL,
  frequencia            VARCHAR(100) NULL,
  duracao_tratamento    VARCHAR(100) NULL,
  quantidade            INT NOT NULL DEFAULT 1,
  PRIMARY KEY (id_consulta_remedio),
  KEY idx_consulta_remedio_consulta (id_consulta),
  KEY idx_consulta_remedio_remedio (id_remedio),
  CONSTRAINT fk_consulta_remedio_consulta FOREIGN KEY (id_consulta)
    REFERENCES consulta (id_consulta) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_consulta_remedio_remedio FOREIGN KEY (id_remedio)
    REFERENCES remedio (id_remedio) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- pagamento
-- -----------------------------------------------------------------------------
-- id_consulta: ON DELETE RESTRICT — diferente de consulta_remedio, um
-- pagamento é um registro financeiro; preferimos bloquear a exclusão de
-- uma consulta com pagamento associado a apagar dinheiro em silêncio.
-- id_caixa: nullable + ON DELETE SET NULL — hoje não existe rota de
-- exclusão de caixa na API (só abrir/fechar), então esse FK só entraria em
-- jogo por uma exclusão manual direta no banco; SET NULL evita travar essa
-- manutenção sem motivo, já que id_caixa aqui já é opcional por natureza.
-- `forma_pagamento` é VARCHAR livre (não ENUM): pagamentoController.criar()
-- não valida contra uma lista fixa de valores, só passa o que o front
-- envia. O front usa como valores observados: dinheiro, cartao_credito,
-- cartao_debito, pix, transferencia — mas o backend não impõe isso, então
-- o schema segue a mesma leniência pra não introduzir uma trava que o
-- código original não tem.
-- `data_pagamento` recebe DEFAULT CURRENT_TIMESTAMP porque
-- pagamentoController.criar() não inclui essa coluna no INSERT.
CREATE TABLE pagamento (
  id_pagamento     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_consulta      INT UNSIGNED NOT NULL,
  id_caixa         INT UNSIGNED NULL,
  valor            DECIMAL(10,2) NOT NULL,
  forma_pagamento  VARCHAR(30) NOT NULL,
  status           ENUM('pendente', 'pago', 'cancelado', 'estornado') NOT NULL DEFAULT 'pendente',
  data_pagamento   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_pagamento),
  KEY idx_pagamento_consulta (id_consulta),
  KEY idx_pagamento_caixa (id_caixa),
  KEY idx_pagamento_status (status),
  KEY idx_pagamento_data (data_pagamento),
  CONSTRAINT fk_pagamento_consulta FOREIGN KEY (id_consulta)
    REFERENCES consulta (id_consulta) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_pagamento_caixa FOREIGN KEY (id_caixa)
    REFERENCES caixa (id_caixa) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------------------------
-- movimentacao_caixa
-- -----------------------------------------------------------------------------
-- id_caixa: ON DELETE CASCADE — assim como pagamento.id_caixa, não existe
-- rota de exclusão de caixa hoje; CASCADE aqui é só uma rede de segurança
-- pra manutenção manual não deixar movimentações órfãs.
-- id_pagamento: nullable + ON DELETE SET NULL — lançamentos manuais (ex:
-- compra de material de limpeza) não têm id_pagamento; os automáticos têm,
-- mas não devem impedir manutenção do registro de pagamento.
-- `data_hora` recebe DEFAULT CURRENT_TIMESTAMP porque
-- caixaController.registrarMovimentacao() não inclui essa coluna no INSERT.
CREATE TABLE movimentacao_caixa (
  id_movimentacao  INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_caixa         INT UNSIGNED NOT NULL,
  id_pagamento     INT UNSIGNED NULL,
  tipo             ENUM('entrada', 'saida') NOT NULL,
  valor            DECIMAL(10,2) NOT NULL,
  descricao        VARCHAR(255) NULL,
  data_hora        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_movimentacao),
  KEY idx_movimentacao_caixa (id_caixa),
  KEY idx_movimentacao_pagamento (id_pagamento),
  CONSTRAINT fk_movimentacao_caixa FOREIGN KEY (id_caixa)
    REFERENCES caixa (id_caixa) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_movimentacao_pagamento FOREIGN KEY (id_pagamento)
    REFERENCES pagamento (id_pagamento) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
