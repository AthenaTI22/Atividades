# Frontend — VetFlow

React 19 + Vite, sem UI kit externo — CSS próprio com design tokens (ver
`src/index.css`), consumindo a API Express do backend.

> Este README cobre só o frontend. Para configurar o projeto inteiro (banco
> + backend + frontend) do zero, veja o `README.md` na raiz do repositório.

## Setup rápido (a partir desta pasta)

```bash
npm install
cp .env.example .env
# ajuste VITE_API_URL se o backend não estiver em localhost:3000
npm run dev
```

Abre em `http://localhost:5173`. O backend precisa estar rodando antes (veja
`../backend/README.md` ou o README da raiz).

## Como o frontend fala com o backend

Não há proxy configurado no `vite.config.js` — o `src/api/client.js` chama a
API diretamente pela URL absoluta em `VITE_API_URL`, e o `cors()` do backend
(sem restrição de origem) é quem libera essa chamada cross-origin em
desenvolvimento. Essa já era a abordagem original dos dois projetos
(confirmado lendo `client.js` e `server.js`); mantivemos como estava — ver
seção 6.1 do prompt de unificação, que permite escolher entre proxy do Vite
ou CORS e documentar a escolha.

## Fluxo pra testar

1. Suba o backend e crie um usuário admin (`node scripts/seedAdmin.js` dentro
   de `backend/`, ou `POST /auth/registrar` — ver README da raiz).
2. Rode `npm run dev` aqui e logue com esse usuário.
3. Cadastre: um cliente → um animal (vinculado ao cliente) → um veterinário
   → agende uma consulta → abra a consulta e mude o status pra
   `em_andamento` → prescreva um remédio → conclua e registre o valor →
   abra um caixa → registre o pagamento da consulta.

## Estrutura

```
src/
  api/client.js           # wrapper de fetch com token JWT injetado +
                           # interceptador de sessão expirada (401/403)
  context/AuthContext.jsx # login/logout, guarda token no localStorage
  components/
    Layout.jsx             # sidebar + área de conteúdo
    RotaProtegida.jsx      # redireciona pro login se não autenticado
    PaginaCrudGenerica.jsx # CRUD configurável (cliente, veterinário, especialidade, remédio)
    Pilula.jsx             # badge de status colorido por ENUM
    Modal.jsx
  pages/
    Login.jsx
    Painel.jsx              # dashboard com métricas do dia
    Clientes.jsx, Veterinarios.jsx, Especialidades.jsx, Remedios.jsx
    Animais.jsx             # CRUD com dropdown de dono
    Consultas.jsx           # agenda + lista
    ConsultaDetalhe.jsx     # fluxo de status + prescrição de remédio
    Caixa.jsx               # abrir/fechar caixa, lançamentos
    Pagamentos.jsx          # registrar pagamento de consulta
```

## Decisões (pra defesa)

- **Sem Redux/Zustand**: o estado é local por página + um `AuthContext`
  global. Pro tamanho desse projeto, `useState`/`useEffect` já resolve sem
  a complexidade extra de uma lib de estado global.
- **`PaginaCrudGenerica`**: as 4 entidades sem regra de negócio especial
  (cliente, veterinário, especialidade, remédio) compartilham um único
  componente configurável, em vez de 4 páginas quase idênticas — mesmo
  raciocínio do `crudGenerico.js` no backend.
- **Controle de acesso na UI**: os botões de criar/editar/excluir só
  aparecem se `tipo_usuario` permite, mas isso é só UX — a autorização de
  verdade é sempre no backend (o botão sumir não impede alguém de chamar
  a API direto).
- **Pílulas de status**: a cor do badge é derivada do próprio valor do
  ENUM (`agendada`, `pago`, `cancelado`...), então cada status novo que o
  banco ganhar no futuro só precisa de uma linha de CSS.

## Aprimoramentos adicionados na unificação (ver seção 6.4 do prompt original)

- **Sessão expirada tratada de forma amigável**: `src/api/client.js` agora
  detecta 401/403 em requisições autenticadas, limpa o `localStorage` e
  redireciona pra `/login?sessao=expirada`, que mostra uma mensagem clara
  em vez de deixar a tela travada num estado inconsistente.
- **Mensagens de erro mais claras quando o backend está indisponível**: uma
  falha de rede no `fetch` (backend fora do ar, sem internet) agora vira uma
  mensagem legível em vez do `TypeError: Failed to fetch` genérico.

## Fora de escopo

- Sem paginação real (via backend) nas tabelas — existe uma busca simples
  client-side sobre os dados já carregados (ver `PaginaCrudGenerica.jsx`),
  suficiente pro volume pequeno de dados de uso acadêmico.
- A tela pública de Cadastro (`/cadastro`) só cria usuários tipo `cliente`
  — por segurança, o backend ignora qualquer `tipo_usuario` enviado pelo
  cliente da requisição em `POST /auth/registrar`. Os primeiros acessos
  `admin`/`recepcionista`/`veterinario` continuam sendo criados só via
  `node scripts/seedAdmin.js` ou diretamente no banco.
