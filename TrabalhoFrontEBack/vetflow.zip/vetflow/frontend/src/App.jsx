import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import RotaProtegida from './components/RotaProtegida';
import Layout from './components/Layout';

import Login from './pages/Login';
import Cadastro from './pages/Cadastro';
import Painel from './pages/Painel';
import Clientes from './pages/Clientes';
import Animais from './pages/Animais';
import Veterinarios from './pages/Veterinarios';
import Especialidades from './pages/Especialidades';
import Remedios from './pages/Remedios';
import Consultas from './pages/Consultas';
import ConsultaDetalhe from './pages/ConsultaDetalhe';
import Caixa from './pages/Caixa';
import Pagamentos from './pages/Pagamentos';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/cadastro" element={<Cadastro />} />
          <Route
            path="/"
            element={
              <RotaProtegida>
                <Layout />
              </RotaProtegida>
            }
          >
            <Route index element={<Painel />} />
            <Route path="clientes" element={<Clientes />} />
            <Route path="animais" element={<Animais />} />
            <Route path="veterinarios" element={<Veterinarios />} />
            <Route path="especialidades" element={<Especialidades />} />
            <Route path="remedios" element={<Remedios />} />
            <Route path="consultas" element={<Consultas />} />
            <Route path="consultas/:id" element={<ConsultaDetalhe />} />
            <Route path="caixa" element={<Caixa />} />
            <Route path="pagamentos" element={<Pagamentos />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
