const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

async function requisicao(caminho, opcoes = {}) {
  const token = localStorage.getItem('token');

  let resposta;
  try {
    resposta = await fetch(`${BASE_URL}${caminho}`, {
      ...opcoes,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...opcoes.headers
      }
    });
  } catch (err) {
    // fetch só rejeita a Promise em falha de rede/CORS (backend fora do ar,
    // sem conexão etc.) — antes isso virava um TypeError genérico e confuso
    // pro usuário final. Mensagem mais clara (aprimoramento 6.4.e).
    throw new Error('Não foi possível conectar ao servidor. Verifique sua internet ou se o backend está no ar, e tente novamente.');
  }

  // 204 No Content não tem corpo pra parsear
  if (resposta.status === 204) return null;

  // Sessão expirada ou token inválido (aprimoramento 6.4.a). Só tratamos
  // como expiração de sessão quando a requisição de fato levava um token —
  // um 401 em /auth/login por senha errada, por exemplo, não tem token e
  // não deve derrubar a sessão nem redirecionar ninguém.
  if ((resposta.status === 401 || resposta.status === 403) && token) {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    if (typeof window !== 'undefined' && window.location.pathname !== '/login') {
      window.location.href = '/login?sessao=expirada';
    }
    throw new Error('Sua sessão expirou. Faça login novamente.');
  }

  const dados = await resposta.json().catch(() => null);

  if (!resposta.ok) {
    const mensagem = dados?.erro || `Erro ${resposta.status}`;
    throw new Error(mensagem);
  }

  return dados;
}

export const api = {
  get: (caminho) => requisicao(caminho),
  post: (caminho, corpo) => requisicao(caminho, { method: 'POST', body: JSON.stringify(corpo) }),
  put: (caminho, corpo) => requisicao(caminho, { method: 'PUT', body: JSON.stringify(corpo) }),
  patch: (caminho, corpo) => requisicao(caminho, { method: 'PATCH', body: JSON.stringify(corpo) }),
  delete: (caminho) => requisicao(caminho, { method: 'DELETE' })
};
