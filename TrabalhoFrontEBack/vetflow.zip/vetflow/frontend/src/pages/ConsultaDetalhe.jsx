import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import Pilula from '../components/Pilula';
import Modal from '../components/Modal';

const STATUS_ORDEM = ['agendada', 'em_andamento', 'concluida', 'cancelada'];

export default function ConsultaDetalhe() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { usuario } = useAuth();
  const podeClinico = ['admin', 'veterinario'].includes(usuario?.tipo_usuario);

  const [consulta, setConsulta] = useState(null);
  const [remedios, setRemedios] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  const [statusForm, setStatusForm] = useState({ status: '', diagnostico: '', observacoes: '', valor: '' });
  const [salvandoStatus, setSalvandoStatus] = useState(false);

  const [modalPrescricao, setModalPrescricao] = useState(false);
  const [formPrescricao, setFormPrescricao] = useState({});
  const [erroPrescricao, setErroPrescricao] = useState('');
  const [salvandoPrescricao, setSalvandoPrescricao] = useState(false);

  async function carregar() {
    setCarregando(true);
    setErro('');
    try {
      const [c, r] = await Promise.all([
        api.get(`/consultas/${id}`),
        podeClinico ? api.get('/remedios') : Promise.resolve([])
      ]);
      setConsulta(c);
      setRemedios(r);
      setStatusForm({
        status: c.status,
        diagnostico: c.diagnostico || '',
        observacoes: c.observacoes || '',
        valor: c.valor
      });
    } catch (err) {
      setErro(err.message);
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => { carregar(); }, [id]);

  async function salvarStatus(e) {
    e.preventDefault();
    setSalvandoStatus(true);
    try {
      await api.patch(`/consultas/${id}/status`, statusForm);
      carregar();
    } catch (err) {
      alert(err.message);
    } finally {
      setSalvandoStatus(false);
    }
  }

  async function adicionarPrescricao(e) {
    e.preventDefault();
    setSalvandoPrescricao(true);
    setErroPrescricao('');
    try {
      await api.post('/prescricoes', { ...formPrescricao, id_consulta: Number(id) });
      setModalPrescricao(false);
      setFormPrescricao({});
      carregar();
    } catch (err) {
      setErroPrescricao(err.message);
    } finally {
      setSalvandoPrescricao(false);
    }
  }

  async function removerPrescricao(idPrescricao) {
    if (!confirm('Cancelar essa prescrição? A quantidade volta pro estoque.')) return;
    try {
      await api.delete(`/prescricoes/${idPrescricao}`);
      carregar();
    } catch (err) {
      alert(err.message);
    }
  }

  if (carregando) return <div className="carregando">Carregando...</div>;
  if (erro) return <div className="erro-form">{erro}</div>;
  if (!consulta) return null;

  return (
    <div>
      <button className="botao-texto" onClick={() => navigate('/consultas')} style={{ marginBottom: 12 }}>← Voltar</button>

      <div className="cabecalho-pagina">
        <div>
          <h1>{consulta.nome_animal}</h1>
          <p>{new Date(consulta.data_hora).toLocaleString('pt-BR')} · Dr(a). {consulta.nome_veterinario}</p>
        </div>
        <Pilula valor={consulta.status} />
      </div>

      <div className="cartao" style={{ padding: 24, marginBottom: 24 }}>
        <h2 style={{ fontSize: 16, marginBottom: 16 }}>Atendimento</h2>
        {consulta.motivo && <p style={{ marginBottom: 16, color: 'var(--cor-texto-suave)' }}><strong>Motivo:</strong> {consulta.motivo}</p>}

        <form onSubmit={salvarStatus}>
          <div className="campo-form">
            <label>Status</label>
            <select
              disabled={!podeClinico}
              value={statusForm.status}
              onChange={e => setStatusForm({ ...statusForm, status: e.target.value })}
            >
              {STATUS_ORDEM.map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
            </select>
          </div>
          <div className="campo-form">
            <label>Diagnóstico</label>
            <textarea
              rows={3}
              disabled={!podeClinico}
              value={statusForm.diagnostico}
              onChange={e => setStatusForm({ ...statusForm, diagnostico: e.target.value })}
            />
          </div>
          <div className="campo-form">
            <label>Observações</label>
            <textarea
              rows={2}
              disabled={!podeClinico}
              value={statusForm.observacoes}
              onChange={e => setStatusForm({ ...statusForm, observacoes: e.target.value })}
            />
          </div>
          <div className="campo-form">
            <label>Valor da consulta (R$)</label>
            <input
              type="number" step="0.01"
              disabled={!podeClinico}
              value={statusForm.valor}
              onChange={e => setStatusForm({ ...statusForm, valor: e.target.value })}
            />
          </div>
          {podeClinico && (
            <button className="botao botao-primario" type="submit" disabled={salvandoStatus}>
              {salvandoStatus ? 'Salvando...' : 'Salvar atendimento'}
            </button>
          )}
        </form>
      </div>

      <div className="cabecalho-pagina" style={{ marginBottom: 12 }}>
        <h2 style={{ fontSize: 16 }}>Remédios prescritos</h2>
        {podeClinico && <button className="botao botao-secundario" onClick={() => setModalPrescricao(true)}>+ Prescrever</button>}
      </div>

      <div className="cartao">
        {(!consulta.remedios_prescritos || consulta.remedios_prescritos.length === 0) ? (
          <div className="tabela-vazia">Nenhum remédio prescrito nessa consulta.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Remédio</th>
                <th>Dosagem</th>
                <th>Frequência</th>
                <th>Duração</th>
                <th>Qtd</th>
                {podeClinico && <th></th>}
              </tr>
            </thead>
            <tbody>
              {consulta.remedios_prescritos.map(p => (
                <tr key={p.id_consulta_remedio}>
                  <td>{p.nome_remedio}</td>
                  <td>{p.dosagem || '—'}</td>
                  <td>{p.frequencia || '—'}</td>
                  <td>{p.duracao_tratamento || '—'}</td>
                  <td>{p.quantidade}</td>
                  {podeClinico && (
                    <td><button className="botao-texto" style={{ color: 'var(--cor-perigo)' }} onClick={() => removerPrescricao(p.id_consulta_remedio)}>Remover</button></td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalPrescricao && (
        <Modal titulo="Prescrever remédio" onFechar={() => setModalPrescricao(false)}>
          <form onSubmit={adicionarPrescricao}>
            {erroPrescricao && <div className="erro-form">{erroPrescricao}</div>}
            <div className="campo-form">
              <label>Remédio *</label>
              <select required value={formPrescricao.id_remedio ?? ''} onChange={e => setFormPrescricao({ ...formPrescricao, id_remedio: e.target.value })}>
                <option value="" disabled>Selecione</option>
                {remedios.map(r => (
                  <option key={r.id_remedio} value={r.id_remedio}>{r.nome} (estoque: {r.estoque})</option>
                ))}
              </select>
            </div>
            <div className="campo-form">
              <label>Dosagem</label>
              <input value={formPrescricao.dosagem ?? ''} onChange={e => setFormPrescricao({ ...formPrescricao, dosagem: e.target.value })} placeholder="ex: 10mg" />
            </div>
            <div className="campo-form">
              <label>Frequência</label>
              <input value={formPrescricao.frequencia ?? ''} onChange={e => setFormPrescricao({ ...formPrescricao, frequencia: e.target.value })} placeholder="ex: a cada 8 horas" />
            </div>
            <div className="campo-form">
              <label>Duração do tratamento</label>
              <input value={formPrescricao.duracao_tratamento ?? ''} onChange={e => setFormPrescricao({ ...formPrescricao, duracao_tratamento: e.target.value })} placeholder="ex: 7 dias" />
            </div>
            <div className="campo-form">
              <label>Quantidade</label>
              <input type="number" min="1" value={formPrescricao.quantidade ?? 1} onChange={e => setFormPrescricao({ ...formPrescricao, quantidade: e.target.value })} />
            </div>
            <div className="acoes-modal">
              <button type="button" className="botao botao-secundario" onClick={() => setModalPrescricao(false)}>Cancelar</button>
              <button type="submit" className="botao botao-primario" disabled={salvandoPrescricao}>{salvandoPrescricao ? 'Salvando...' : 'Prescrever'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
