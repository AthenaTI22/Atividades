import { useEffect, useState } from 'react';
import { api } from '../api/client';
import Modal from '../components/Modal';
import Pilula from '../components/Pilula';

export default function Caixa() {
  const [caixas, setCaixas] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  const [modalAbrir, setModalAbrir] = useState(false);
  const [formAbrir, setFormAbrir] = useState({ valor_abertura: '', responsavel_abertura: '' });
  const [erroAbrir, setErroAbrir] = useState('');

  const [caixaSelecionado, setCaixaSelecionado] = useState(null);
  const [modalMovimentacao, setModalMovimentacao] = useState(false);
  const [formMov, setFormMov] = useState({ tipo: 'saida', valor: '', descricao: '' });
  const [erroMov, setErroMov] = useState('');

  const [modalFechar, setModalFechar] = useState(false);
  const [formFechar, setFormFechar] = useState({ responsavel_fechamento: '' });
  const [erroFechar, setErroFechar] = useState('');

  const [salvando, setSalvando] = useState(false);

  async function carregar() {
    setCarregando(true);
    setErro('');
    try {
      setCaixas(await api.get('/caixas'));
    } catch (err) {
      setErro(err.message);
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => { carregar(); }, []);

  const caixaAberto = caixas.find(c => c.status === 'aberto');

  async function abrirCaixa(e) {
    e.preventDefault();
    setSalvando(true);
    setErroAbrir('');
    try {
      await api.post('/caixas/abrir', formAbrir);
      setModalAbrir(false);
      setFormAbrir({ valor_abertura: '', responsavel_abertura: '' });
      carregar();
    } catch (err) {
      setErroAbrir(err.message);
    } finally {
      setSalvando(false);
    }
  }

  async function abrirDetalhes(caixa) {
    try {
      const detalhe = await api.get(`/caixas/${caixa.id_caixa}`);
      setCaixaSelecionado(detalhe);
    } catch (err) {
      alert(err.message);
    }
  }

  async function registrarMovimentacao(e) {
    e.preventDefault();
    setSalvando(true);
    setErroMov('');
    try {
      await api.post(`/caixas/${caixaSelecionado.id_caixa}/movimentacao`, formMov);
      setModalMovimentacao(false);
      setFormMov({ tipo: 'saida', valor: '', descricao: '' });
      const detalhe = await api.get(`/caixas/${caixaSelecionado.id_caixa}`);
      setCaixaSelecionado(detalhe);
      carregar();
    } catch (err) {
      setErroMov(err.message);
    } finally {
      setSalvando(false);
    }
  }

  async function fecharCaixa(e) {
    e.preventDefault();
    setSalvando(true);
    setErroFechar('');
    try {
      await api.patch(`/caixas/${caixaSelecionado.id_caixa}/fechar`, formFechar);
      setModalFechar(false);
      setCaixaSelecionado(null);
      setFormFechar({ responsavel_fechamento: '' });
      carregar();
    } catch (err) {
      setErroFechar(err.message);
    } finally {
      setSalvando(false);
    }
  }

  return (
    <div>
      <div className="cabecalho-pagina">
        <div>
          <h1>Caixa</h1>
          <p>Controle financeiro do dia a dia da clínica</p>
        </div>
        {!caixaAberto && <button className="botao botao-primario" onClick={() => setModalAbrir(true)}>Abrir caixa</button>}
      </div>

      <div className="cartao">
        {carregando ? (
          <div className="carregando">Carregando...</div>
        ) : erro ? (
          <div className="tabela-vazia">{erro}</div>
        ) : caixas.length === 0 ? (
          <div className="tabela-vazia">Nenhum caixa aberto ainda.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Abertura</th>
                <th>Responsável</th>
                <th>Valor abertura</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {caixas.map(c => (
                <tr key={c.id_caixa}>
                  <td>{new Date(c.data_abertura).toLocaleString('pt-BR')}</td>
                  <td>{c.responsavel_abertura}</td>
                  <td>R$ {Number(c.valor_abertura).toFixed(2)}</td>
                  <td><Pilula valor={c.status} /></td>
                  <td><button className="botao-texto" onClick={() => abrirDetalhes(c)}>Ver</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalAbrir && (
        <Modal titulo="Abrir caixa" onFechar={() => setModalAbrir(false)}>
          <form onSubmit={abrirCaixa}>
            {erroAbrir && <div className="erro-form">{erroAbrir}</div>}
            <div className="campo-form">
              <label>Valor de abertura (R$) *</label>
              <input type="number" step="0.01" required value={formAbrir.valor_abertura} onChange={e => setFormAbrir({ ...formAbrir, valor_abertura: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Responsável *</label>
              <input required value={formAbrir.responsavel_abertura} onChange={e => setFormAbrir({ ...formAbrir, responsavel_abertura: e.target.value })} />
            </div>
            <div className="acoes-modal">
              <button type="button" className="botao botao-secundario" onClick={() => setModalAbrir(false)}>Cancelar</button>
              <button type="submit" className="botao botao-primario" disabled={salvando}>{salvando ? 'Abrindo...' : 'Abrir'}</button>
            </div>
          </form>
        </Modal>
      )}

      {caixaSelecionado && (
        <Modal titulo={`Caixa #${caixaSelecionado.id_caixa}`} onFechar={() => setCaixaSelecionado(null)}>
          <p style={{ marginBottom: 8 }}><strong>Status:</strong> <Pilula valor={caixaSelecionado.status} /></p>
          <p style={{ marginBottom: 8 }}>Abertura: R$ {Number(caixaSelecionado.valor_abertura).toFixed(2)} por {caixaSelecionado.responsavel_abertura}</p>
          {caixaSelecionado.status === 'fechado' && (
            <p style={{ marginBottom: 16 }}>Fechamento: R$ {Number(caixaSelecionado.valor_fechamento).toFixed(2)} por {caixaSelecionado.responsavel_fechamento}</p>
          )}

          <h3 style={{ fontSize: 14, margin: '16px 0 8px' }}>Movimentações</h3>
          {(!caixaSelecionado.movimentacoes || caixaSelecionado.movimentacoes.length === 0) ? (
            <p style={{ color: 'var(--cor-texto-suave)', fontSize: 13 }}>Nenhuma movimentação ainda.</p>
          ) : (
            <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13 }}>
              {caixaSelecionado.movimentacoes.map(m => (
                <li key={m.id_movimentacao}>
                  {m.tipo === 'entrada' ? '+' : '-'} R$ {Number(m.valor).toFixed(2)} — {m.descricao || m.tipo}
                </li>
              ))}
            </ul>
          )}

          {caixaSelecionado.status === 'aberto' && (
            <div className="acoes-modal">
              <button className="botao botao-secundario" onClick={() => setModalMovimentacao(true)}>+ Lançamento</button>
              <button className="botao botao-primario" onClick={() => setModalFechar(true)}>Fechar caixa</button>
            </div>
          )}
        </Modal>
      )}

      {modalMovimentacao && (
        <Modal titulo="Novo lançamento" onFechar={() => setModalMovimentacao(false)}>
          <form onSubmit={registrarMovimentacao}>
            {erroMov && <div className="erro-form">{erroMov}</div>}
            <div className="campo-form">
              <label>Tipo</label>
              <select value={formMov.tipo} onChange={e => setFormMov({ ...formMov, tipo: e.target.value })}>
                <option value="entrada">Entrada</option>
                <option value="saida">Saída</option>
              </select>
            </div>
            <div className="campo-form">
              <label>Valor (R$) *</label>
              <input type="number" step="0.01" required value={formMov.valor} onChange={e => setFormMov({ ...formMov, valor: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Descrição</label>
              <input value={formMov.descricao} onChange={e => setFormMov({ ...formMov, descricao: e.target.value })} placeholder="ex: compra de material de limpeza" />
            </div>
            <div className="acoes-modal">
              <button type="button" className="botao botao-secundario" onClick={() => setModalMovimentacao(false)}>Cancelar</button>
              <button type="submit" className="botao botao-primario" disabled={salvando}>{salvando ? 'Salvando...' : 'Lançar'}</button>
            </div>
          </form>
        </Modal>
      )}

      {modalFechar && (
        <Modal titulo="Fechar caixa" onFechar={() => setModalFechar(false)}>
          <form onSubmit={fecharCaixa}>
            {erroFechar && <div className="erro-form">{erroFechar}</div>}
            <div className="campo-form">
              <label>Responsável pelo fechamento *</label>
              <input required value={formFechar.responsavel_fechamento} onChange={e => setFormFechar({ ...formFechar, responsavel_fechamento: e.target.value })} />
            </div>
            <p style={{ fontSize: 13, color: 'var(--cor-texto-suave)' }}>O valor esperado é calculado automaticamente a partir da abertura e das movimentações.</p>
            <div className="acoes-modal">
              <button type="button" className="botao botao-secundario" onClick={() => setModalFechar(false)}>Cancelar</button>
              <button type="submit" className="botao botao-primario" disabled={salvando}>{salvando ? 'Fechando...' : 'Fechar caixa'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
