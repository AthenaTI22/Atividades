import PaginaCrudGenerica from '../components/PaginaCrudGenerica';
import { useAuth } from '../context/AuthContext';

export default function Veterinarios() {
  const { usuario } = useAuth();
  const podeEscrever = usuario?.tipo_usuario === 'admin';

  return (
    <PaginaCrudGenerica
      titulo="Veterinários"
      descricao="Equipe clínica cadastrada no sistema"
      endpoint="/veterinarios"
      idChave="id_veterinario"
      podeEscrever={podeEscrever}
      colunas={[
        { chave: 'nome', rotulo: 'Nome' },
        { chave: 'crmv', rotulo: 'CRMV' },
        { chave: 'telefone', rotulo: 'Telefone' },
        { chave: 'email', rotulo: 'Email' }
      ]}
      campos={[
        { nome: 'nome', rotulo: 'Nome', obrigatorio: true },
        { nome: 'crmv', rotulo: 'CRMV', obrigatorio: true },
        { nome: 'telefone', rotulo: 'Telefone' },
        { nome: 'email', rotulo: 'Email', tipo: 'email' },
        { nome: 'data_contratacao', rotulo: 'Data de contratação', tipo: 'date' }
      ]}
    />
  );
}
