import PaginaCrudGenerica from '../components/PaginaCrudGenerica';
import { useAuth } from '../context/AuthContext';

export default function Clientes() {
  const { usuario } = useAuth();
  const podeEscrever = ['admin', 'recepcionista'].includes(usuario?.tipo_usuario);

  return (
    <PaginaCrudGenerica
      titulo="Clientes"
      descricao="Donos dos animais atendidos na clínica"
      endpoint="/clientes"
      idChave="id_cliente"
      podeEscrever={podeEscrever}
      colunas={[
        { chave: 'nome', rotulo: 'Nome' },
        { chave: 'cpf', rotulo: 'CPF' },
        { chave: 'telefone', rotulo: 'Telefone' },
        { chave: 'email', rotulo: 'Email' }
      ]}
      campos={[
        { nome: 'nome', rotulo: 'Nome', obrigatorio: true },
        {
          nome: 'cpf', rotulo: 'CPF', obrigatorio: true,
          placeholder: '000.000.000-00',
          pattern: '\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}',
          title: 'Use o formato 000.000.000-00',
          maxLength: 14
        },
        { nome: 'telefone', rotulo: 'Telefone', obrigatorio: true },
        { nome: 'email', rotulo: 'Email', tipo: 'email' },
        { nome: 'endereco', rotulo: 'Endereço' }
      ]}
    />
  );
}
