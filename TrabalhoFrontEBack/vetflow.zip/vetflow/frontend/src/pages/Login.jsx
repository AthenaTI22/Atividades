import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  // Mensagem de sessão expirada (aprimoramento 6.4.a): o client.js redireciona
  // pra cá com ?sessao=expirada quando um 401/403 acontece numa rota autenticada.
  const [erro, setErro] = useState(
    searchParams.get('sessao') === 'expirada' ? 'Sua sessão expirou. Faça login novamente.' : ''
  );
  const [carregando, setCarregando] = useState(false);
  const { entrar } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setErro('');
    setCarregando(true);
    try {
      await entrar(email, senha);
      navigate('/');
    } catch (err) {
      setErro(err.message || 'Não foi possível entrar');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="tela-login">
      <div className="cartao-login">
        <div className="marca">
          <span aria-hidden="true" style={{ fontSize: 26 }}>🐾</span>
          <span>VetFlow</span>
        </div>
        <p className="subtitulo">Entre com sua conta pra acessar o painel da clínica.</p>

        <form onSubmit={handleSubmit}>
          {erro && <div className="erro-form">{erro}</div>}
          <div className="campo-form">
            <label htmlFor="email">Email</label>
            <input id="email" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="voce@clinica.com" />
          </div>
          <div className="campo-form">
            <label htmlFor="senha">Senha</label>
            <input id="senha" type="password" required value={senha} onChange={e => setSenha(e.target.value)} placeholder="••••••••" />
          </div>
          <button className="botao botao-primario" type="submit" disabled={carregando}>
            {carregando ? 'Entrando...' : 'Entrar'}
          </button>
        </form>

        <p className="rodape-login">
          Não tem conta? <Link to="/cadastro">Cadastre-se</Link>
        </p>
      </div>
    </div>
  );
}
