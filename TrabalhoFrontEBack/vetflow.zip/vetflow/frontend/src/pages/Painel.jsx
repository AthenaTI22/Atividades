import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import Pilula from '../components/Pilula';

export default function Painel() {
  const { usuario } = useAuth();
  const [consultas, setConsultas] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  useEffect(() => {
    api.get('/consultas')
      .then(setConsultas)
      .catch(err => setErro(err.message))
      .finally(() => setCarregando(false));
  }, []);

  const hoje = new Date().toISOString().slice(0, 10);
  const consultasHoje = consultas.filter(c => c.data_hora?.slice(0, 10) === hoje);
  const agendadas = consultas.filter(c => c.status === 'agendada');
  const emAndamento = consultas.filter(c => c.status === 'em_andamento');

  return (
    <div>
      <div className="cabecalho-pagina">
        <div>
          <h1>Olá, {usuario?.nome?.split(' ')[0]}</h1>
          <p>Aqui está o panorama da clínica hoje.</p>
        </div>
      </div>

      {erro && <div className="erro-form">{erro}</div>}

      <div className="grade-cartoes">
        <div className="cartao-metrica">
          <span className="numero">{carregando ? '—' : consultasHoje.length}</span>
          <span className="rotulo">Consultas hoje</span>
        </div>
        <div className="cartao-metrica">
          <span className="numero">{carregando ? '—' : agendadas.length}</span>
          <span className="rotulo">Aguardando atendimento</span>
        </div>
        <div className="cartao-metrica">
          <span className="numero">{carregando ? '—' : emAndamento.length}</span>
          <span className="rotulo">Em andamento agora</span>
        </div>
      </div>

      <h2 style={{ fontSize: 18, marginBottom: 12 }}>Próximas consultas</h2>
      <div className="cartao">
        {carregando ? (
          <div className="carregando">Carregando...</div>
        ) : consultas.length === 0 ? (
          <div className="tabela-vazia">Nenhuma consulta agendada ainda.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Data/hora</th>
                <th>Animal</th>
                <th>Veterinário</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {consultas.slice(0, 8).map(c => (
                <tr key={c.id_consulta}>
                  <td>{new Date(c.data_hora).toLocaleString('pt-BR')}</td>
                  <td>{c.nome_animal}</td>
                  <td>{c.nome_veterinario}</td>
                  <td><Pilula valor={c.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      <p style={{ marginTop: 16 }}>
        <Link to="/consultas" className="botao-texto">Ver todas as consultas →</Link>
      </p>
    </div>
  );
}
