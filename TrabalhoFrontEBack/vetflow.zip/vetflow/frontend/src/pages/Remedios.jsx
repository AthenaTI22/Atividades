import PaginaCrudGenerica from '../components/PaginaCrudGenerica';
import { useAuth } from '../context/AuthContext';

export default function Remedios() {
  const { usuario } = useAuth();
  const podeEscrever = ['admin', 'recepcionista'].includes(usuario?.tipo_usuario);

  return (
    <PaginaCrudGenerica
      titulo="Remédios"
      descricao="Estoque de medicamentos usados nas prescrições"
      endpoint="/remedios"
      idChave="id_remedio"
      podeEscrever={podeEscrever}
      colunas={[
        { chave: 'nome', rotulo: 'Nome' },
        { chave: 'fabricante', rotulo: 'Fabricante' },
        { chave: 'forma_farmaceutica', rotulo: 'Forma' },
        { chave: 'preco_unitario', rotulo: 'Preço', render: (v) => `R$ ${Number(v).toFixed(2)}` },
        {
          chave: 'estoque', rotulo: 'Estoque',
          render: (v) => <span style={{ color: v < 10 ? 'var(--cor-perigo)' : 'inherit', fontWeight: v < 10 ? 600 : 400 }}>{v}</span>
        }
      ]}
      campos={[
        { nome: 'nome', rotulo: 'Nome', obrigatorio: true },
        { nome: 'fabricante', rotulo: 'Fabricante' },
        { nome: 'principio_ativo', rotulo: 'Princípio ativo' },
        { nome: 'forma_farmaceutica', rotulo: 'Forma farmacêutica (ex: comprimido)' },
        { nome: 'preco_unitario', rotulo: 'Preço unitário', tipo: 'number', obrigatorio: true },
        { nome: 'estoque', rotulo: 'Estoque', tipo: 'number', obrigatorio: true }
      ]}
    />
  );
}
