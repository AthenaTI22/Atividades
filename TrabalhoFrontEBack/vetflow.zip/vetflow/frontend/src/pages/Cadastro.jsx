import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client';

// Tela pública de autocadastro. Chama POST /auth/registrar, que (por
// segurança) sempre cria o usuário como tipo_usuario 'cliente' no backend —
// por isso este formulário nem envia esse campo. Ver comentário em
// backend/controllers/authController.js.
export default function Cadastro() {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);
  const [sucesso, setSucesso] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setErro('');

    if (senha !== confirmarSenha) {
      setErro('As senhas não conferem');
      return;
    }
    if (senha.length < 6) {
      setErro('A senha deve ter pelo menos 6 caracteres');
      return;
    }

    setCarregando(true);
    try {
      // Note: não enviamos tipo_usuario de propósito — todo autocadastro
      // público vira 'cliente' (decisão de segurança, ver Tarefa 2.5).
      await api.post('/auth/registrar', { nome, email, senha });
      setSucesso(true);
      setTimeout(() => navigate('/login'), 1500);
    } catch (err) {
      setErro(err.message || 'Não foi possível concluir o cadastro');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="tela-login">
      <div className="cartao-login">
        <div className="marca">
          <span aria-hidden="true" style={{ fontSize: 26 }}>🐾</span>
          <span>VetFlow</span>
        </div>
        <p className="subtitulo">Crie sua conta de cliente para acompanhar seus atendimentos.</p>

        {sucesso ? (
          <div className="campo-form" style={{ color: 'var(--cor-primaria-escura)', fontWeight: 600 }}>
            Cadastro concluído! Redirecionando para o login...
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {erro && <div className="erro-form">{erro}</div>}
            <div className="campo-form">
              <label htmlFor="nome">Nome</label>
              <input id="nome" type="text" required value={nome} onChange={e => setNome(e.target.value)} placeholder="Seu nome completo" />
            </div>
            <div className="campo-form">
              <label htmlFor="email">Email</label>
              <input id="email" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="voce@email.com" />
            </div>
            <div className="campo-form">
              <label htmlFor="senha">Senha</label>
              <input id="senha" type="password" required minLength={6} value={senha} onChange={e => setSenha(e.target.value)} placeholder="••••••••" />
            </div>
            <div className="campo-form">
              <label htmlFor="confirmarSenha">Confirmar senha</label>
              <input id="confirmarSenha" type="password" required minLength={6} value={confirmarSenha} onChange={e => setConfirmarSenha(e.target.value)} placeholder="••••••••" />
            </div>
            <button className="botao botao-primario" type="submit" disabled={carregando}>
              {carregando ? 'Cadastrando...' : 'Criar conta'}
            </button>
          </form>
        )}

        <p className="rodape-login">
          Já tem conta? <Link to="/login">Entrar</Link>
        </p>
      </div>
    </div>
  );
}
