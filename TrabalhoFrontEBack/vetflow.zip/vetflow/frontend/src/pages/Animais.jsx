import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import Modal from '../components/Modal';

export default function Animais() {
  const { usuario } = useAuth();
  const podeEscrever = ['admin', 'recepcionista'].includes(usuario?.tipo_usuario);

  const [animais, setAnimais] = useState([]);
  const [clientes, setClientes] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erroLista, setErroLista] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [itemEditando, setItemEditando] = useState(null);
  const [form, setForm] = useState({});
  const [erroForm, setErroForm] = useState('');
  const [salvando, setSalvando] = useState(false);

  async function carregar() {
    setCarregando(true);
    setErroLista('');
    try {
      const [listaAnimais, listaClientes] = await Promise.all([
        api.get('/animais'),
        podeEscrever ? api.get('/clientes') : Promise.resolve([])
      ]);
      setAnimais(listaAnimais);
      setClientes(listaClientes);
    } catch (err) {
      setErroLista(err.message);
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => { carregar(); }, []);

  function abrirNovo() {
    setItemEditando(null);
    setForm({ sexo: 'M' });
    setErroForm('');
    setModalAberto(true);
  }

  function abrirEdicao(item) {
    setItemEditando(item);
    setForm({ ...item });
    setErroForm('');
    setModalAberto(true);
  }

  async function salvar(e) {
    e.preventDefault();
    setSalvando(true);
    setErroForm('');
    try {
      if (itemEditando) {
        await api.put(`/animais/${itemEditando.id_animal}`, form);
      } else {
        await api.post('/animais', form);
      }
      setModalAberto(false);
      carregar();
    } catch (err) {
      setErroForm(err.message);
    } finally {
      setSalvando(false);
    }
  }

  async function excluir(item) {
    if (!confirm(`Excluir "${item.nome}"? Isso também apaga o histórico de consultas dele.`)) return;
    try {
      await api.delete(`/animais/${item.id_animal}`);
      carregar();
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <div>
      <div className="cabecalho-pagina">
        <div>
          <h1>Animais</h1>
          <p>Pacientes cadastrados e seus donos</p>
        </div>
        {podeEscrever && <button className="botao botao-primario" onClick={abrirNovo}>+ Novo</button>}
      </div>

      <div className="cartao">
        {carregando ? (
          <div className="carregando">Carregando...</div>
        ) : erroLista ? (
          <div className="tabela-vazia">{erroLista}</div>
        ) : animais.length === 0 ? (
          <div className="tabela-vazia">Nenhum animal cadastrado ainda.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Nome</th>
                <th>Espécie</th>
                <th>Raça</th>
                <th>Dono</th>
                {podeEscrever && <th style={{ width: 140 }}>Ações</th>}
              </tr>
            </thead>
            <tbody>
              {animais.map(a => (
                <tr key={a.id_animal}>
                  <td>{a.nome}</td>
                  <td>{a.especie}</td>
                  <td>{a.raca || '—'}</td>
                  <td>{a.nome_dono}</td>
                  {podeEscrever && (
                    <td>
                      <div className="linha-acoes">
                        <button className="botao-texto" onClick={() => abrirEdicao(a)}>Editar</button>
                        <button className="botao-texto" style={{ color: 'var(--cor-perigo)' }} onClick={() => excluir(a)}>Excluir</button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalAberto && (
        <Modal titulo={itemEditando ? 'Editar animal' : 'Novo animal'} onFechar={() => setModalAberto(false)}>
          <form onSubmit={salvar}>
            {erroForm && <div className="erro-form">{erroForm}</div>}
            <div className="campo-form">
              <label>Nome *</label>
              <input required value={form.nome ?? ''} onChange={e => setForm({ ...form, nome: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Espécie *</label>
              <input required placeholder="Cão, Gato..." value={form.especie ?? ''} onChange={e => setForm({ ...form, especie: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Raça</label>
              <input value={form.raca ?? ''} onChange={e => setForm({ ...form, raca: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Data de nascimento</label>
              <input type="date" value={form.data_nascimento ?? ''} onChange={e => setForm({ ...form, data_nascimento: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Sexo</label>
              <select value={form.sexo ?? 'M'} onChange={e => setForm({ ...form, sexo: e.target.value })}>
                <option value="M">Macho</option>
                <option value="F">Fêmea</option>
              </select>
            </div>
            <div className="campo-form">
              <label>Peso (kg)</label>
              <input type="number" step="0.01" value={form.peso ?? ''} onChange={e => setForm({ ...form, peso: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Dono *</label>
              <select required value={form.id_cliente ?? ''} onChange={e => setForm({ ...form, id_cliente: e.target.value })}>
                <option value="" disabled>Selecione um cliente</option>
                {clientes.map(c => (
                  <option key={c.id_cliente} value={c.id_cliente}>{c.nome}</option>
                ))}
              </select>
            </div>
            <div className="acoes-modal">
              <button type="button" className="botao botao-secundario" onClick={() => setModalAberto(false)}>Cancelar</button>
              <button type="submit" className="botao botao-primario" disabled={salvando}>{salvando ? 'Salvando...' : 'Salvar'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
