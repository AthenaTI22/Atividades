import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import Modal from '../components/Modal';
import Pilula from '../components/Pilula';

export default function Consultas() {
  const { usuario } = useAuth();
  const podeAgendar = ['admin', 'recepcionista'].includes(usuario?.tipo_usuario);

  const [consultas, setConsultas] = useState([]);
  const [animais, setAnimais] = useState([]);
  const [veterinarios, setVeterinarios] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erroLista, setErroLista] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [form, setForm] = useState({});
  const [erroForm, setErroForm] = useState('');
  const [salvando, setSalvando] = useState(false);

  async function carregar() {
    setCarregando(true);
    setErroLista('');
    try {
      const [c, a, v] = await Promise.all([
        api.get('/consultas'),
        podeAgendar ? api.get('/animais') : Promise.resolve([]),
        podeAgendar ? api.get('/veterinarios') : Promise.resolve([])
      ]);
      setConsultas(c);
      setAnimais(a);
      setVeterinarios(v);
    } catch (err) {
      setErroLista(err.message);
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => { carregar(); }, []);

  function abrirNovo() {
    setForm({});
    setErroForm('');
    setModalAberto(true);
  }

  async function salvar(e) {
    e.preventDefault();
    setSalvando(true);
    setErroForm('');
    try {
      await api.post('/consultas', form);
      setModalAberto(false);
      carregar();
    } catch (err) {
      setErroForm(err.message);
    } finally {
      setSalvando(false);
    }
  }

  return (
    <div>
      <div className="cabecalho-pagina">
        <div>
          <h1>Consultas</h1>
          <p>Agenda clínica e histórico de atendimentos</p>
        </div>
        {podeAgendar && <button className="botao botao-primario" onClick={abrirNovo}>+ Agendar</button>}
      </div>

      <div className="cartao">
        {carregando ? (
          <div className="carregando">Carregando...</div>
        ) : erroLista ? (
          <div className="tabela-vazia">{erroLista}</div>
        ) : consultas.length === 0 ? (
          <div className="tabela-vazia">Nenhuma consulta agendada ainda.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Data/hora</th>
                <th>Animal</th>
                <th>Veterinário</th>
                <th>Status</th>
                <th>Valor</th>
                <th style={{ width: 90 }}></th>
              </tr>
            </thead>
            <tbody>
              {consultas.map(c => (
                <tr key={c.id_consulta}>
                  <td>{new Date(c.data_hora).toLocaleString('pt-BR')}</td>
                  <td>{c.nome_animal}</td>
                  <td>{c.nome_veterinario}</td>
                  <td><Pilula valor={c.status} /></td>
                  <td>R$ {Number(c.valor).toFixed(2)}</td>
                  <td><Link className="botao-texto" to={`/consultas/${c.id_consulta}`}>Abrir</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalAberto && (
        <Modal titulo="Agendar consulta" onFechar={() => setModalAberto(false)}>
          <form onSubmit={salvar}>
            {erroForm && <div className="erro-form">{erroForm}</div>}
            <div className="campo-form">
              <label>Animal *</label>
              <select required value={form.id_animal ?? ''} onChange={e => setForm({ ...form, id_animal: e.target.value })}>
                <option value="" disabled>Selecione um animal</option>
                {animais.map(a => (
                  <option key={a.id_animal} value={a.id_animal}>{a.nome} ({a.nome_dono})</option>
                ))}
              </select>
            </div>
            <div className="campo-form">
              <label>Veterinário *</label>
              <select required value={form.id_veterinario ?? ''} onChange={e => setForm({ ...form, id_veterinario: e.target.value })}>
                <option value="" disabled>Selecione um veterinário</option>
                {veterinarios.map(v => (
                  <option key={v.id_veterinario} value={v.id_veterinario}>{v.nome}</option>
                ))}
              </select>
            </div>
            <div className="campo-form">
              <label>Data e hora *</label>
              <input type="datetime-local" required value={form.data_hora ?? ''} onChange={e => setForm({ ...form, data_hora: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Motivo</label>
              <textarea rows={2} value={form.motivo ?? ''} onChange={e => setForm({ ...form, motivo: e.target.value })} />
            </div>
            <div className="acoes-modal">
              <button type="button" className="botao botao-secundario" onClick={() => setModalAberto(false)}>Cancelar</button>
              <button type="submit" className="botao botao-primario" disabled={salvando}>{salvando ? 'Agendando...' : 'Agendar'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
