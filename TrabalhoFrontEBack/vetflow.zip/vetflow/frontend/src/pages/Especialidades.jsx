import PaginaCrudGenerica from '../components/PaginaCrudGenerica';
import { useAuth } from '../context/AuthContext';

export default function Especialidades() {
  const { usuario } = useAuth();
  const podeEscrever = usuario?.tipo_usuario === 'admin';

  return (
    <PaginaCrudGenerica
      titulo="Especialidades"
      descricao="Áreas de atuação disponíveis pra vincular aos veterinários"
      endpoint="/especialidades"
      idChave="id_especialidade"
      podeEscrever={podeEscrever}
      colunas={[
        { chave: 'nome', rotulo: 'Nome' },
        { chave: 'descricao', rotulo: 'Descrição' }
      ]}
      campos={[
        { nome: 'nome', rotulo: 'Nome', obrigatorio: true },
        { nome: 'descricao', rotulo: 'Descrição', tipo: 'textarea' }
      ]}
    />
  );
}
