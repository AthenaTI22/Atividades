import { useEffect, useState } from 'react';
import { api } from '../api/client';
import Modal from '../components/Modal';
import Pilula from '../components/Pilula';

const FORMAS = ['dinheiro', 'cartao_credito', 'cartao_debito', 'pix', 'transferencia'];

export default function Pagamentos() {
  const [pagamentos, setPagamentos] = useState([]);
  const [consultas, setConsultas] = useState([]);
  const [caixas, setCaixas] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  const [modalAberto, setModalAberto] = useState(false);
  const [form, setForm] = useState({ forma_pagamento: 'pix', status: 'pago' });
  const [erroForm, setErroForm] = useState('');
  const [salvando, setSalvando] = useState(false);

  async function carregar() {
    setCarregando(true);
    setErro('');
    try {
      const [p, c, cx] = await Promise.all([
        api.get('/pagamentos'),
        api.get('/consultas'),
        api.get('/caixas')
      ]);
      setPagamentos(p);
      setConsultas(c);
      setCaixas(cx);
    } catch (err) {
      setErro(err.message);
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => { carregar(); }, []);

  const caixaAberto = caixas.find(c => c.status === 'aberto');

  function abrirNovo() {
    setForm({ forma_pagamento: 'pix', status: 'pago', id_caixa: caixaAberto?.id_caixa || '' });
    setErroForm('');
    setModalAberto(true);
  }

  async function salvar(e) {
    e.preventDefault();
    setSalvando(true);
    setErroForm('');
    try {
      await api.post('/pagamentos', form);
      setModalAberto(false);
      carregar();
    } catch (err) {
      setErroForm(err.message);
    } finally {
      setSalvando(false);
    }
  }

  async function marcarComoPago(pagamento) {
    try {
      await api.patch(`/pagamentos/${pagamento.id_pagamento}/status`, { status: 'pago' });
      carregar();
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <div>
      <div className="cabecalho-pagina">
        <div>
          <h1>Pagamentos</h1>
          <p>Cobranças vinculadas às consultas</p>
        </div>
        <button className="botao botao-primario" onClick={abrirNovo}>+ Registrar pagamento</button>
      </div>

      {!caixaAberto && (
        <div className="erro-form" style={{ background: 'var(--cor-alerta-clara)', color: '#8A6414', marginBottom: 16 }}>
          Nenhum caixa está aberto agora — pagamentos marcados como "pago" não vão gerar lançamento no caixa até um ser aberto.
        </div>
      )}

      <div className="cartao">
        {carregando ? (
          <div className="carregando">Carregando...</div>
        ) : erro ? (
          <div className="tabela-vazia">{erro}</div>
        ) : pagamentos.length === 0 ? (
          <div className="tabela-vazia">Nenhum pagamento registrado ainda.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Data</th>
                <th>Consulta</th>
                <th>Forma</th>
                <th>Valor</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {pagamentos.map(p => (
                <tr key={p.id_pagamento}>
                  <td>{new Date(p.data_pagamento).toLocaleString('pt-BR')}</td>
                  <td>#{p.id_consulta}</td>
                  <td style={{ textTransform: 'capitalize' }}>{p.forma_pagamento.replace('_', ' ')}</td>
                  <td>R$ {Number(p.valor).toFixed(2)}</td>
                  <td><Pilula valor={p.status} /></td>
                  <td>
                    {p.status === 'pendente' && (
                      <button className="botao-texto" onClick={() => marcarComoPago(p)}>Marcar como pago</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalAberto && (
        <Modal titulo="Registrar pagamento" onFechar={() => setModalAberto(false)}>
          <form onSubmit={salvar}>
            {erroForm && <div className="erro-form">{erroForm}</div>}
            <div className="campo-form">
              <label>Consulta *</label>
              <select required value={form.id_consulta ?? ''} onChange={e => setForm({ ...form, id_consulta: e.target.value })}>
                <option value="" disabled>Selecione</option>
                {consultas.map(c => (
                  <option key={c.id_consulta} value={c.id_consulta}>
                    #{c.id_consulta} — {c.nome_animal} — R$ {Number(c.valor).toFixed(2)}
                  </option>
                ))}
              </select>
            </div>
            <div className="campo-form">
              <label>Valor (R$) *</label>
              <input type="number" step="0.01" required value={form.valor ?? ''} onChange={e => setForm({ ...form, valor: e.target.value })} />
            </div>
            <div className="campo-form">
              <label>Forma de pagamento</label>
              <select value={form.forma_pagamento} onChange={e => setForm({ ...form, forma_pagamento: e.target.value })}>
                {FORMAS.map(f => <option key={f} value={f}>{f.replace('_', ' ')}</option>)}
              </select>
            </div>
            <div className="campo-form">
              <label>Status</label>
              <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                <option value="pago">Pago</option>
                <option value="pendente">Pendente</option>
              </select>
            </div>
            <div className="acoes-modal">
              <button type="button" className="botao botao-secundario" onClick={() => setModalAberto(false)}>Cancelar</button>
              <button type="submit" className="botao botao-primario" disabled={salvando}>{salvando ? 'Salvando...' : 'Registrar'}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
