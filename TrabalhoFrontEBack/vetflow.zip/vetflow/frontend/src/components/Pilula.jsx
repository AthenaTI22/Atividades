export default function Pilula({ valor }) {
  if (!valor) return null;
  return <span className={`pilula pilula-${valor}`}>{valor.replace('_', ' ')}</span>;
}
