import { useEffect, useState } from 'react';
import { api } from '../api/client';
import Modal from './Modal';

/**
 * Página CRUD configurável, usada pra entidades sem regra de negócio
 * especial (cliente, veterinário, especialidade, remédio). Evita recriar
 * a mesma tabela + modal + form em 4 páginas React diferentes — espelha
 * o mesmo raciocínio do crudGenerico.js no backend.
 */
export default function PaginaCrudGenerica({ titulo, descricao, endpoint, idChave, colunas, campos, podeEscrever }) {
  const [itens, setItens] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erroLista, setErroLista] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [itemEditando, setItemEditando] = useState(null);
  const [form, setForm] = useState({});
  const [erroForm, setErroForm] = useState('');
  const [salvando, setSalvando] = useState(false);
  // Busca simples client-side (aprimoramento de baixo risco, ver Tarefa 4):
  // os dados já vêm inteiros do backend (não há paginação na API), então
  // filtrar no cliente sobre o que já foi carregado é suficiente e não
  // exige nenhuma alteração de backend.
  const [busca, setBusca] = useState('');

  const itensFiltrados = busca.trim()
    ? itens.filter(item =>
        colunas.some(c => {
          const valor = item[c.chave];
          return valor != null && String(valor).toLowerCase().includes(busca.trim().toLowerCase());
        })
      )
    : itens;

  async function carregar() {
    setCarregando(true);
    setErroLista('');
    try {
      const dados = await api.get(endpoint);
      setItens(dados);
    } catch (err) {
      setErroLista(err.message);
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => { carregar(); }, [endpoint]);

  function abrirNovo() {
    setItemEditando(null);
    setForm({});
    setErroForm('');
    setModalAberto(true);
  }

  function abrirEdicao(item) {
    setItemEditando(item);
    setForm({ ...item });
    setErroForm('');
    setModalAberto(true);
  }

  async function salvar(e) {
    e.preventDefault();
    setSalvando(true);
    setErroForm('');
    try {
      if (itemEditando) {
        await api.put(`${endpoint}/${itemEditando[idChave]}`, form);
      } else {
        await api.post(endpoint, form);
      }
      setModalAberto(false);
      carregar();
    } catch (err) {
      setErroForm(err.message);
    } finally {
      setSalvando(false);
    }
  }

  async function excluir(item) {
    if (!confirm(`Excluir "${item[colunas[0].chave]}"? Essa ação não pode ser desfeita.`)) return;
    try {
      await api.delete(`${endpoint}/${item[idChave]}`);
      carregar();
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <div>
      <div className="cabecalho-pagina">
        <div>
          <h1>{titulo}</h1>
          {descricao && <p>{descricao}</p>}
        </div>
        {podeEscrever && (
          <button className="botao botao-primario" onClick={abrirNovo}>+ Novo</button>
        )}
      </div>

      <div className="cartao">
        {!carregando && !erroLista && itens.length > 0 && (
          <div className="campo-form" style={{ maxWidth: 320, marginBottom: 16 }}>
            <input
              type="search"
              placeholder={`Buscar em ${titulo.toLowerCase()}...`}
              value={busca}
              onChange={e => setBusca(e.target.value)}
              aria-label={`Buscar em ${titulo}`}
            />
          </div>
        )}
        {carregando ? (
          <div className="carregando">Carregando...</div>
        ) : erroLista ? (
          <div className="tabela-vazia">{erroLista}</div>
        ) : itens.length === 0 ? (
          <div className="tabela-vazia">Nenhum registro ainda. {podeEscrever && 'Clique em "+ Novo" pra cadastrar o primeiro.'}</div>
        ) : itensFiltrados.length === 0 ? (
          <div className="tabela-vazia">Nenhum resultado para "{busca}".</div>
        ) : (
          <table>
            <thead>
              <tr>
                {colunas.map(c => <th key={c.chave}>{c.rotulo}</th>)}
                {podeEscrever && <th style={{ width: 140 }}>Ações</th>}
              </tr>
            </thead>
            <tbody>
              {itensFiltrados.map(item => (
                <tr key={item[idChave]}>
                  {colunas.map(c => (
                    <td key={c.chave}>{c.render ? c.render(item[c.chave], item) : (item[c.chave] ?? '—')}</td>
                  ))}
                  {podeEscrever && (
                    <td>
                      <div className="linha-acoes">
                        <button className="botao-texto" onClick={() => abrirEdicao(item)}>Editar</button>
                        <button className="botao-texto" style={{ color: 'var(--cor-perigo)' }} onClick={() => excluir(item)}>Excluir</button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalAberto && (
        <Modal titulo={itemEditando ? `Editar ${titulo.replace(/s$/, '')}` : `Novo(a) ${titulo.replace(/s$/, '')}`} onFechar={() => setModalAberto(false)}>
          <form onSubmit={salvar}>
            {erroForm && <div className="erro-form">{erroForm}</div>}
            {campos.map(campo => (
              <div className="campo-form" key={campo.nome}>
                <label htmlFor={campo.nome}>{campo.rotulo}{campo.obrigatorio && ' *'}</label>
                {campo.tipo === 'textarea' ? (
                  <textarea
                    id={campo.nome}
                    rows={3}
                    required={campo.obrigatorio}
                    value={form[campo.nome] ?? ''}
                    onChange={e => setForm({ ...form, [campo.nome]: e.target.value })}
                  />
                ) : (
                  <input
                    id={campo.nome}
                    type={campo.tipo || 'text'}
                    step={campo.tipo === 'number' ? '0.01' : undefined}
                    required={campo.obrigatorio}
                    pattern={campo.pattern}
                    maxLength={campo.maxLength}
                    title={campo.title}
                    placeholder={campo.placeholder}
                    value={form[campo.nome] ?? ''}
                    onChange={e => setForm({ ...form, [campo.nome]: e.target.value })}
                  />
                )}
              </div>
            ))}
            <div className="acoes-modal">
              <button type="button" className="botao botao-secundario" onClick={() => setModalAberto(false)}>Cancelar</button>
              <button type="submit" className="botao botao-primario" disabled={salvando}>
                {salvando ? 'Salvando...' : 'Salvar'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
