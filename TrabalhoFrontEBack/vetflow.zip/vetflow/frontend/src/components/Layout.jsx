import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ITENS_NAV = [
  { rota: '/', rotulo: 'Painel', roles: ['admin', 'recepcionista', 'veterinario', 'cliente'] },
  { rota: '/consultas', rotulo: 'Consultas', roles: ['admin', 'recepcionista', 'veterinario', 'cliente'] },
  { rota: '/animais', rotulo: 'Animais', roles: ['admin', 'recepcionista', 'veterinario', 'cliente'] },
  { rota: '/clientes', rotulo: 'Clientes', roles: ['admin', 'recepcionista'] },
  { rota: '/veterinarios', rotulo: 'Veterinários', roles: ['admin', 'recepcionista'] },
  { rota: '/especialidades', rotulo: 'Especialidades', roles: ['admin'] },
  { rota: '/remedios', rotulo: 'Remédios', roles: ['admin', 'recepcionista', 'veterinario'] },
  { rota: '/caixa', rotulo: 'Caixa', roles: ['admin', 'recepcionista'] },
  { rota: '/pagamentos', rotulo: 'Pagamentos', roles: ['admin', 'recepcionista'] }
];

export default function Layout() {
  const { usuario, sair } = useAuth();
  const navigate = useNavigate();

  function handleSair() {
    sair();
    navigate('/login');
  }

  const itensVisiveis = ITENS_NAV.filter(item => item.roles.includes(usuario?.tipo_usuario));

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-logo">
          <span aria-hidden="true">🐾</span>
          <span>VetFlow</span>
        </div>
        <nav className="sidebar-nav">
          {itensVisiveis.map(item => (
            <NavLink
              key={item.rota}
              to={item.rota}
              end={item.rota === '/'}
              className={({ isActive }) => (isActive ? 'ativo' : '')}
            >
              {item.rotulo}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-rodape">
          <div>{usuario?.nome}</div>
          <div style={{ textTransform: 'capitalize', opacity: 0.8 }}>{usuario?.tipo_usuario}</div>
          <button className="sidebar-sair" onClick={handleSair}>Sair</button>
        </div>
      </aside>
      <main className="conteudo">
        <Outlet />
      </main>
    </div>
  );
}
