export default function Modal({ titulo, onFechar, children }) {
  return (
    <div className="overlay-modal" onClick={onFechar}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2 style={{ marginBottom: 20, fontSize: 20 }}>{titulo}</h2>
        {children}
      </div>
    </div>
  );
}
