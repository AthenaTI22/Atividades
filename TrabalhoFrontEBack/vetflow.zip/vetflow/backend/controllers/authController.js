const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');
require('dotenv').config();

// POST /auth/registrar
// Cria um usuário de login. id_cliente/id_veterinario são opcionais e
// servem pra vincular o login a um registro já existente nessas tabelas
// (ex: um cliente que já foi cadastrado na recepção agora quer acessar o sistema).
async function registrar(req, res) {
  try {
    const { nome, email, senha, id_cliente, id_veterinario } = req.body;

    if (!nome || !email || !senha) {
      return res.status(400).json({ erro: 'nome, email e senha são obrigatórios' });
    }

    // SEGURANÇA: este é o endpoint público de autocadastro (usado pela tela
    // de Cadastro do frontend). Qualquer usuário que se cria por aqui é
    // SEMPRE 'cliente' — o campo tipo_usuario do corpo da requisição é
    // ignorado de propósito, mesmo que alguém monte a requisição HTTP na
    // mão (curl/Postman) tentando enviar tipo_usuario: 'admin'. Papéis
    // administrativos/recepcionista/veterinário só são atribuídos
    // internamente: por um admin editando o registro diretamente, ou por
    // scripts/seedAdmin.js (ver Tarefa 3 das instruções). Antes desta
    // correção, o endpoint aceitava tipo_usuario vindo do corpo da
    // requisição sem nenhuma checagem de autenticação — uma falha de
    // escalonamento de privilégio (qualquer um podia se autocadastrar
    // como admin).
    const tipo = 'cliente';

    const [existente] = await pool.query('SELECT id_usuario FROM usuario WHERE email = ?', [email]);
    if (existente.length > 0) {
      return res.status(409).json({ erro: 'Já existe um usuário com esse email' });
    }

    const senhaHash = await bcrypt.hash(senha, 10);

    const [resultado] = await pool.query(
      `INSERT INTO usuario (nome, email, senha, tipo_usuario, id_cliente, id_veterinario)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [nome, email, senhaHash, tipo, id_cliente || null, id_veterinario || null]
    );

    return res.status(201).json({ id_usuario: resultado.insertId, nome, email, tipo_usuario: tipo });
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao registrar usuário', detalhe: err.message });
  }
}

// POST /auth/login
async function login(req, res) {
  try {
    const { email, senha } = req.body;
    if (!email || !senha) {
      return res.status(400).json({ erro: 'email e senha são obrigatórios' });
    }

    const [rows] = await pool.query('SELECT * FROM usuario WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ erro: 'Credenciais inválidas' });
    }

    const usuario = rows[0];
    const senhaConfere = await bcrypt.compare(senha, usuario.senha);
    if (!senhaConfere) {
      return res.status(401).json({ erro: 'Credenciais inválidas' });
    }

    await pool.query('UPDATE usuario SET ultimo_login = NOW() WHERE id_usuario = ?', [usuario.id_usuario]);

    const payload = {
      id_usuario: usuario.id_usuario,
      tipo_usuario: usuario.tipo_usuario,
      id_cliente: usuario.id_cliente,
      id_veterinario: usuario.id_veterinario
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '8h'
    });

    return res.json({
      token,
      usuario: { id_usuario: usuario.id_usuario, nome: usuario.nome, email: usuario.email, tipo_usuario: usuario.tipo_usuario }
    });
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao fazer login', detalhe: err.message });
  }
}

module.exports = { registrar, login };
