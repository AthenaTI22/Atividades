const pool = require('../config/db');

async function listarPorVeterinario(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT e.id_especialidade, e.nome, e.descricao
       FROM veterinario_especialidade ve
       JOIN especialidade e ON e.id_especialidade = ve.id_especialidade
       WHERE ve.id_veterinario = ?`,
      [req.params.idVeterinario]
    );
    return res.json(rows);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao listar especialidades do veterinário', detalhe: err.message });
  }
}

async function vincular(req, res) {
  try {
    const { id_especialidade } = req.body;
    if (!id_especialidade) return res.status(400).json({ erro: 'id_especialidade é obrigatório' });

    await pool.query(
      'INSERT INTO veterinario_especialidade (id_veterinario, id_especialidade) VALUES (?, ?)',
      [req.params.idVeterinario, id_especialidade]
    );
    return res.status(201).json({ id_veterinario: Number(req.params.idVeterinario), id_especialidade });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ erro: 'Veterinário já possui essa especialidade' });
    return res.status(500).json({ erro: 'Erro ao vincular especialidade', detalhe: err.message });
  }
}

async function desvincular(req, res) {
  try {
    const [resultado] = await pool.query(
      'DELETE FROM veterinario_especialidade WHERE id_veterinario = ? AND id_especialidade = ?',
      [req.params.idVeterinario, req.params.idEspecialidade]
    );
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Vínculo não encontrado' });
    return res.status(204).send();
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao desvincular especialidade', detalhe: err.message });
  }
}

module.exports = { listarPorVeterinario, vincular, desvincular };
