const pool = require('../config/db');

async function listar(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT co.*, a.nome AS nome_animal, v.nome AS nome_veterinario
       FROM consulta co
       JOIN animal a ON a.id_animal = co.id_animal
       JOIN veterinario v ON v.id_veterinario = co.id_veterinario
       ORDER BY co.data_hora DESC`
    );
    return res.json(rows);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao listar consultas', detalhe: err.message });
  }
}

async function buscarPorId(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT co.*, a.nome AS nome_animal, v.nome AS nome_veterinario
       FROM consulta co
       JOIN animal a ON a.id_animal = co.id_animal
       JOIN veterinario v ON v.id_veterinario = co.id_veterinario
       WHERE co.id_consulta = ?`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ erro: 'Consulta não encontrada' });

    const [remedios] = await pool.query(
      `SELECT cr.*, r.nome AS nome_remedio
       FROM consulta_remedio cr
       JOIN remedio r ON r.id_remedio = cr.id_remedio
       WHERE cr.id_consulta = ?`,
      [req.params.id]
    );

    return res.json({ ...rows[0], remedios_prescritos: remedios });
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao buscar consulta', detalhe: err.message });
  }
}

// Agenda uma nova consulta. Status sempre nasce 'agendada' — diagnóstico e
// valor final só fazem sentido depois do atendimento (ver atualizarStatus).
async function criar(req, res) {
  try {
    const { id_animal, id_veterinario, data_hora, motivo } = req.body;
    if (!id_animal || !id_veterinario || !data_hora) {
      return res.status(400).json({ erro: 'id_animal, id_veterinario e data_hora são obrigatórios' });
    }

    const [[animalExiste], [vetExiste]] = await Promise.all([
      pool.query('SELECT id_animal FROM animal WHERE id_animal = ?', [id_animal]),
      pool.query('SELECT id_veterinario FROM veterinario WHERE id_veterinario = ?', [id_veterinario])
    ]);
    if (animalExiste.length === 0) return res.status(400).json({ erro: 'id_animal informado não existe' });
    if (vetExiste.length === 0) return res.status(400).json({ erro: 'id_veterinario informado não existe' });

    const [resultado] = await pool.query(
      `INSERT INTO consulta (id_animal, id_veterinario, data_hora, motivo, status)
       VALUES (?, ?, ?, ?, 'agendada')`,
      [id_animal, id_veterinario, data_hora, motivo || null]
    );
    const [nova] = await pool.query('SELECT * FROM consulta WHERE id_consulta = ?', [resultado.insertId]);
    return res.status(201).json(nova[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao criar consulta', detalhe: err.message });
  }
}

// Atualiza dados administrativos (data, motivo) — não mexe em status/diagnóstico
async function atualizar(req, res) {
  try {
    const campos = ['data_hora', 'motivo', 'id_veterinario'];
    const enviados = campos.filter(c => req.body[c] !== undefined);
    if (enviados.length === 0) return res.status(400).json({ erro: 'Nenhum campo válido enviado' });

    const setClause = enviados.map(c => `${c} = ?`).join(', ');
    const valores = enviados.map(c => req.body[c]);
    valores.push(req.params.id);

    const [resultado] = await pool.query(`UPDATE consulta SET ${setClause} WHERE id_consulta = ?`, valores);
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Consulta não encontrada' });

    const [atualizada] = await pool.query('SELECT * FROM consulta WHERE id_consulta = ?', [req.params.id]);
    return res.json(atualizada[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao atualizar consulta', detalhe: err.message });
  }
}

// Fluxo clínico: agendada -> em_andamento -> concluida (ou cancelada a qualquer momento).
// É aqui que diagnóstico, observações e valor final da consulta são registrados.
async function atualizarStatus(req, res) {
  try {
    const { status, diagnostico, observacoes, valor } = req.body;
    const statusValidos = ['agendada', 'em_andamento', 'concluida', 'cancelada'];
    if (!statusValidos.includes(status)) {
      return res.status(400).json({ erro: `status deve ser um de: ${statusValidos.join(', ')}` });
    }

    const campos = ['status'];
    const valores = [status];
    if (diagnostico !== undefined) { campos.push('diagnostico'); valores.push(diagnostico); }
    if (observacoes !== undefined) { campos.push('observacoes'); valores.push(observacoes); }
    if (valor !== undefined) { campos.push('valor'); valores.push(valor); }

    const setClause = campos.map(c => `${c} = ?`).join(', ');
    valores.push(req.params.id);

    const [resultado] = await pool.query(`UPDATE consulta SET ${setClause} WHERE id_consulta = ?`, valores);
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Consulta não encontrada' });

    const [atualizada] = await pool.query('SELECT * FROM consulta WHERE id_consulta = ?', [req.params.id]);
    return res.json(atualizada[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao atualizar status da consulta', detalhe: err.message });
  }
}

async function deletar(req, res) {
  try {
    const [resultado] = await pool.query('DELETE FROM consulta WHERE id_consulta = ?', [req.params.id]);
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Consulta não encontrada' });
    return res.status(204).send();
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao excluir consulta', detalhe: err.message });
  }
}

module.exports = { listar, buscarPorId, criar, atualizar, atualizarStatus, deletar };
