const pool = require('../config/db');

// Prescreve um remédio numa consulta E dá baixa no estoque, tudo numa
// transação: se uma das duas operações falhar, a outra é desfeita.
// Isso resolve o problema de "fonte dupla de verdade" pro estoque —
// remedio.estoque é a ÚNICA fonte, e só muda por aqui (ou por um
// futuro endpoint de reposição/compra).
async function criar(req, res) {
  const conexao = await pool.getConnection();
  try {
    const { id_consulta, id_remedio, dosagem, frequencia, duracao_tratamento, quantidade } = req.body;
    const qtd = quantidade || 1;

    if (!id_consulta || !id_remedio) {
      conexao.release();
      return res.status(400).json({ erro: 'id_consulta e id_remedio são obrigatórios' });
    }

    await conexao.beginTransaction();

    const [[remedio]] = await conexao.query(
      'SELECT estoque, preco_unitario FROM remedio WHERE id_remedio = ? FOR UPDATE',
      [id_remedio]
    );
    if (!remedio) {
      await conexao.rollback();
      conexao.release();
      return res.status(400).json({ erro: 'id_remedio informado não existe' });
    }
    if (remedio.estoque < qtd) {
      await conexao.rollback();
      conexao.release();
      return res.status(409).json({ erro: `Estoque insuficiente (disponível: ${remedio.estoque})` });
    }

    const [resultado] = await conexao.query(
      `INSERT INTO consulta_remedio (id_consulta, id_remedio, dosagem, frequencia, duracao_tratamento, quantidade)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id_consulta, id_remedio, dosagem || null, frequencia || null, duracao_tratamento || null, qtd]
    );

    await conexao.query('UPDATE remedio SET estoque = estoque - ? WHERE id_remedio = ?', [qtd, id_remedio]);

    await conexao.commit();
    conexao.release();

    return res.status(201).json({
      id_consulta_remedio: resultado.insertId,
      id_consulta, id_remedio, dosagem, frequencia, duracao_tratamento,
      quantidade: qtd,
      preco_unitario_no_momento: remedio.preco_unitario // repassar pro front calcular o valor da consulta
    });
  } catch (err) {
    await conexao.rollback();
    conexao.release();
    return res.status(500).json({ erro: 'Erro ao prescrever remédio', detalhe: err.message });
  }
}

// Cancela uma prescrição e devolve a quantidade ao estoque
async function deletar(req, res) {
  const conexao = await pool.getConnection();
  try {
    await conexao.beginTransaction();

    const [[prescricao]] = await conexao.query(
      'SELECT id_remedio, quantidade FROM consulta_remedio WHERE id_consulta_remedio = ?',
      [req.params.id]
    );
    if (!prescricao) {
      await conexao.rollback();
      conexao.release();
      return res.status(404).json({ erro: 'Prescrição não encontrada' });
    }

    await conexao.query('DELETE FROM consulta_remedio WHERE id_consulta_remedio = ?', [req.params.id]);
    await conexao.query('UPDATE remedio SET estoque = estoque + ? WHERE id_remedio = ?', [prescricao.quantidade, prescricao.id_remedio]);

    await conexao.commit();
    conexao.release();
    return res.status(204).send();
  } catch (err) {
    await conexao.rollback();
    conexao.release();
    return res.status(500).json({ erro: 'Erro ao cancelar prescrição', detalhe: err.message });
  }
}

async function listarPorConsulta(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT cr.*, r.nome AS nome_remedio, r.preco_unitario
       FROM consulta_remedio cr
       JOIN remedio r ON r.id_remedio = cr.id_remedio
       WHERE cr.id_consulta = ?`,
      [req.params.idConsulta]
    );
    return res.json(rows);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao listar prescrições', detalhe: err.message });
  }
}

module.exports = { criar, deletar, listarPorConsulta };
