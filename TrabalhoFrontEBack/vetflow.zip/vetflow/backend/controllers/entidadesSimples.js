const criarCrudGenerico = require('./crudGenerico');

const clienteController = criarCrudGenerico(
  'cliente', 'id_cliente',
  ['nome', 'cpf', 'telefone', 'email', 'endereco']
);

const especialidadeController = criarCrudGenerico(
  'especialidade', 'id_especialidade',
  ['nome', 'descricao']
);

const veterinarioController = criarCrudGenerico(
  'veterinario', 'id_veterinario',
  ['nome', 'crmv', 'telefone', 'email', 'data_contratacao']
);

const remedioController = criarCrudGenerico(
  'remedio', 'id_remedio',
  ['nome', 'fabricante', 'principio_ativo', 'forma_farmaceutica', 'preco_unitario', 'estoque']
);

module.exports = {
  clienteController,
  especialidadeController,
  veterinarioController,
  remedioController
};
