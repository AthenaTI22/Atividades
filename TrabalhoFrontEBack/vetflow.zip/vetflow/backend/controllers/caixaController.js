const pool = require('../config/db');

async function listar(req, res) {
  try {
    const [rows] = await pool.query('SELECT * FROM caixa ORDER BY id_caixa DESC');
    return res.json(rows);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao listar caixas', detalhe: err.message });
  }
}

async function buscarPorId(req, res) {
  try {
    const [rows] = await pool.query('SELECT * FROM caixa WHERE id_caixa = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ erro: 'Caixa não encontrado' });

    const [movimentacoes] = await pool.query(
      'SELECT * FROM movimentacao_caixa WHERE id_caixa = ? ORDER BY data_hora', [req.params.id]
    );
    return res.json({ ...rows[0], movimentacoes });
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao buscar caixa', detalhe: err.message });
  }
}

// Só pode existir um caixa 'aberto' por vez — evita duas pessoas abrindo
// caixa ao mesmo tempo e bagunçando o financeiro do dia.
async function abrir(req, res) {
  try {
    const { valor_abertura, responsavel_abertura, observacoes } = req.body;
    if (valor_abertura === undefined || !responsavel_abertura) {
      return res.status(400).json({ erro: 'valor_abertura e responsavel_abertura são obrigatórios' });
    }

    const [aberto] = await pool.query("SELECT id_caixa FROM caixa WHERE status = 'aberto'");
    if (aberto.length > 0) {
      return res.status(409).json({ erro: `Já existe um caixa aberto (id ${aberto[0].id_caixa}). Feche-o antes de abrir outro.` });
    }

    const [resultado] = await pool.query(
      `INSERT INTO caixa (data_abertura, valor_abertura, responsavel_abertura, status, observacoes)
       VALUES (NOW(), ?, ?, 'aberto', ?)`,
      [valor_abertura, responsavel_abertura, observacoes || null]
    );
    const [novo] = await pool.query('SELECT * FROM caixa WHERE id_caixa = ?', [resultado.insertId]);
    return res.status(201).json(novo[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao abrir caixa', detalhe: err.message });
  }
}

// Fecha o caixa calculando o valor esperado a partir das movimentações reais
// (abertura + entradas - saídas), e registra o valor informado pelo
// responsável pra bater/conferir na hora do fechamento.
async function fechar(req, res) {
  try {
    const { responsavel_fechamento, valor_fechamento_informado } = req.body;
    if (!responsavel_fechamento) {
      return res.status(400).json({ erro: 'responsavel_fechamento é obrigatório' });
    }

    const [[caixa]] = await pool.query('SELECT * FROM caixa WHERE id_caixa = ?', [req.params.id]);
    if (!caixa) return res.status(404).json({ erro: 'Caixa não encontrado' });
    if (caixa.status === 'fechado') return res.status(409).json({ erro: 'Este caixa já está fechado' });

    const [[somatorio]] = await pool.query(
      `SELECT
         COALESCE(SUM(CASE WHEN tipo = 'entrada' THEN valor ELSE 0 END), 0) AS total_entradas,
         COALESCE(SUM(CASE WHEN tipo = 'saida' THEN valor ELSE 0 END), 0) AS total_saidas
       FROM movimentacao_caixa WHERE id_caixa = ?`,
      [req.params.id]
    );

    const valorEsperado = Number(caixa.valor_abertura) + Number(somatorio.total_entradas) - Number(somatorio.total_saidas);
    const valorFinal = valor_fechamento_informado !== undefined ? valor_fechamento_informado : valorEsperado;

    await pool.query(
      `UPDATE caixa SET data_fechamento = NOW(), valor_fechamento = ?, responsavel_fechamento = ?, status = 'fechado' WHERE id_caixa = ?`,
      [valorFinal, responsavel_fechamento, req.params.id]
    );

    const [atualizado] = await pool.query('SELECT * FROM caixa WHERE id_caixa = ?', [req.params.id]);
    return res.json({
      ...atualizado[0],
      valor_esperado: valorEsperado,
      diferenca: Number(valorFinal) - valorEsperado
    });
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao fechar caixa', detalhe: err.message });
  }
}

// Lançamento manual (ex: saída pra compra de material de limpeza)
async function registrarMovimentacao(req, res) {
  try {
    const { tipo, valor, descricao } = req.body;
    if (!['entrada', 'saida'].includes(tipo) || !valor) {
      return res.status(400).json({ erro: "tipo ('entrada'/'saida') e valor são obrigatórios" });
    }

    const [[caixa]] = await pool.query('SELECT status FROM caixa WHERE id_caixa = ?', [req.params.id]);
    if (!caixa) return res.status(404).json({ erro: 'Caixa não encontrado' });
    if (caixa.status === 'fechado') return res.status(409).json({ erro: 'Não é possível movimentar um caixa fechado' });

    const [resultado] = await pool.query(
      `INSERT INTO movimentacao_caixa (id_caixa, tipo, valor, descricao) VALUES (?, ?, ?, ?)`,
      [req.params.id, tipo, valor, descricao || null]
    );
    const [nova] = await pool.query('SELECT * FROM movimentacao_caixa WHERE id_movimentacao = ?', [resultado.insertId]);
    return res.status(201).json(nova[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao registrar movimentação', detalhe: err.message });
  }
}

module.exports = { listar, buscarPorId, abrir, fechar, registrarMovimentacao };
