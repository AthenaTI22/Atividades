const pool = require('../config/db');

async function listar(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT p.*, co.data_hora AS data_consulta
       FROM pagamento p
       JOIN consulta co ON co.id_consulta = p.id_consulta
       ORDER BY p.data_pagamento DESC`
    );
    return res.json(rows);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao listar pagamentos', detalhe: err.message });
  }
}

async function buscarPorId(req, res) {
  try {
    const [rows] = await pool.query('SELECT * FROM pagamento WHERE id_pagamento = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ erro: 'Pagamento não encontrado' });
    return res.json(rows[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao buscar pagamento', detalhe: err.message });
  }
}

// Registra o pagamento de uma consulta. Se vier com status 'pago' e vinculado
// a um caixa aberto, já lança automaticamente a entrada em movimentacao_caixa
// — assim o financeiro não depende de alguém lembrar de lançar manualmente.
async function criar(req, res) {
  const conexao = await pool.getConnection();
  try {
    const { id_consulta, id_caixa, valor, forma_pagamento, status } = req.body;
    if (!id_consulta || !valor || !forma_pagamento) {
      conexao.release();
      return res.status(400).json({ erro: 'id_consulta, valor e forma_pagamento são obrigatórios' });
    }

    const statusFinal = status || 'pendente';
    await conexao.beginTransaction();

    const [resultado] = await conexao.query(
      `INSERT INTO pagamento (id_consulta, id_caixa, valor, forma_pagamento, status)
       VALUES (?, ?, ?, ?, ?)`,
      [id_consulta, id_caixa || null, valor, forma_pagamento, statusFinal]
    );

    if (statusFinal === 'pago' && id_caixa) {
      const [[caixa]] = await conexao.query('SELECT status FROM caixa WHERE id_caixa = ?', [id_caixa]);
      if (caixa && caixa.status === 'aberto') {
        await conexao.query(
          `INSERT INTO movimentacao_caixa (id_caixa, id_pagamento, tipo, valor, descricao)
           VALUES (?, ?, 'entrada', ?, ?)`,
          [id_caixa, resultado.insertId, valor, `Pagamento consulta #${id_consulta}`]
        );
      }
    }

    await conexao.commit();
    conexao.release();

    const [novo] = await pool.query('SELECT * FROM pagamento WHERE id_pagamento = ?', [resultado.insertId]);
    return res.status(201).json(novo[0]);
  } catch (err) {
    await conexao.rollback();
    conexao.release();
    return res.status(500).json({ erro: 'Erro ao registrar pagamento', detalhe: err.message });
  }
}

// Muda status (ex: pendente -> pago, ou -> estornado). Só lança movimentação
// nova se a transição for justamente pra 'pago' (evita duplicar lançamento
// se o pagamento já nasceu como 'pago' via criar()).
async function atualizarStatus(req, res) {
  const conexao = await pool.getConnection();
  try {
    const { status } = req.body;
    const statusValidos = ['pendente', 'pago', 'cancelado', 'estornado'];
    if (!statusValidos.includes(status)) {
      conexao.release();
      return res.status(400).json({ erro: `status deve ser um de: ${statusValidos.join(', ')}` });
    }

    await conexao.beginTransaction();
    const [[pagamento]] = await conexao.query('SELECT * FROM pagamento WHERE id_pagamento = ?', [req.params.id]);
    if (!pagamento) {
      await conexao.rollback();
      conexao.release();
      return res.status(404).json({ erro: 'Pagamento não encontrado' });
    }

    await conexao.query('UPDATE pagamento SET status = ? WHERE id_pagamento = ?', [status, req.params.id]);

    if (status === 'pago' && pagamento.status !== 'pago' && pagamento.id_caixa) {
      const [[caixa]] = await conexao.query('SELECT status FROM caixa WHERE id_caixa = ?', [pagamento.id_caixa]);
      if (caixa && caixa.status === 'aberto') {
        await conexao.query(
          `INSERT INTO movimentacao_caixa (id_caixa, id_pagamento, tipo, valor, descricao)
           VALUES (?, ?, 'entrada', ?, ?)`,
          [pagamento.id_caixa, pagamento.id_pagamento, pagamento.valor, `Pagamento consulta #${pagamento.id_consulta}`]
        );
      }
    }

    await conexao.commit();
    conexao.release();

    const [atualizado] = await pool.query('SELECT * FROM pagamento WHERE id_pagamento = ?', [req.params.id]);
    return res.json(atualizado[0]);
  } catch (err) {
    await conexao.rollback();
    conexao.release();
    return res.status(500).json({ erro: 'Erro ao atualizar status do pagamento', detalhe: err.message });
  }
}

module.exports = { listar, buscarPorId, criar, atualizarStatus };
