const pool = require('../config/db');

/**
 * Gera um controller CRUD básico pra tabelas sem lógica de negócio especial
 * (cliente, especialidade, veterinario, remedio, caixa). Evita repetir o
 * mesmo SELECT/INSERT/UPDATE/DELETE em 5 arquivos diferentes.
 *
 * @param {string} tabela - nome da tabela
 * @param {string} pk - nome da coluna de chave primária
 * @param {string[]} campos - whitelist de colunas aceitas em criar/atualizar
 *                            (nunca confiar direto em req.body inteiro)
 */
function criarCrudGenerico(tabela, pk, campos) {
  async function listar(req, res) {
    try {
      const [rows] = await pool.query(`SELECT * FROM ${tabela} ORDER BY ${pk} DESC`);
      return res.json(rows);
    } catch (err) {
      return res.status(500).json({ erro: `Erro ao listar ${tabela}`, detalhe: err.message });
    }
  }

  async function buscarPorId(req, res) {
    try {
      const [rows] = await pool.query(`SELECT * FROM ${tabela} WHERE ${pk} = ?`, [req.params.id]);
      if (rows.length === 0) return res.status(404).json({ erro: `${tabela} não encontrado(a)` });
      return res.json(rows[0]);
    } catch (err) {
      return res.status(500).json({ erro: `Erro ao buscar ${tabela}`, detalhe: err.message });
    }
  }

  async function criar(req, res) {
    try {
      const valores = campos.map(c => (req.body[c] !== undefined ? req.body[c] : null));
      const placeholders = campos.map(() => '?').join(', ');
      const [resultado] = await pool.query(
        `INSERT INTO ${tabela} (${campos.join(', ')}) VALUES (${placeholders})`,
        valores
      );
      const [novoRegistro] = await pool.query(`SELECT * FROM ${tabela} WHERE ${pk} = ?`, [resultado.insertId]);
      return res.status(201).json(novoRegistro[0]);
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ erro: 'Registro duplicado', detalhe: err.message });
      return res.status(500).json({ erro: `Erro ao criar ${tabela}`, detalhe: err.message });
    }
  }

  async function atualizar(req, res) {
    try {
      const camposEnviados = campos.filter(c => req.body[c] !== undefined);
      if (camposEnviados.length === 0) {
        return res.status(400).json({ erro: 'Nenhum campo válido enviado para atualização' });
      }
      const setClause = camposEnviados.map(c => `${c} = ?`).join(', ');
      const valores = camposEnviados.map(c => req.body[c]);
      valores.push(req.params.id);

      const [resultado] = await pool.query(`UPDATE ${tabela} SET ${setClause} WHERE ${pk} = ?`, valores);
      if (resultado.affectedRows === 0) return res.status(404).json({ erro: `${tabela} não encontrado(a)` });

      const [atualizado] = await pool.query(`SELECT * FROM ${tabela} WHERE ${pk} = ?`, [req.params.id]);
      return res.json(atualizado[0]);
    } catch (err) {
      return res.status(500).json({ erro: `Erro ao atualizar ${tabela}`, detalhe: err.message });
    }
  }

  async function deletar(req, res) {
    try {
      const [resultado] = await pool.query(`DELETE FROM ${tabela} WHERE ${pk} = ?`, [req.params.id]);
      if (resultado.affectedRows === 0) return res.status(404).json({ erro: `${tabela} não encontrado(a)` });
      return res.status(204).send();
    } catch (err) {
      // FK RESTRICT (ex: veterinario com consultas) cai aqui
      if (err.code === 'ER_ROW_IS_REFERENCED_2') {
        return res.status(409).json({ erro: `Não é possível excluir: existem registros vinculados a este(a) ${tabela}` });
      }
      return res.status(500).json({ erro: `Erro ao excluir ${tabela}`, detalhe: err.message });
    }
  }

  return { listar, buscarPorId, criar, atualizar, deletar };
}

module.exports = criarCrudGenerico;
