const pool = require('../config/db');

async function listar(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT a.*, c.nome AS nome_dono, c.telefone AS telefone_dono
       FROM animal a
       JOIN cliente c ON c.id_cliente = a.id_cliente
       ORDER BY a.id_animal DESC`
    );
    return res.json(rows);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao listar animais', detalhe: err.message });
  }
}

async function buscarPorId(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT a.*, c.nome AS nome_dono, c.telefone AS telefone_dono
       FROM animal a
       JOIN cliente c ON c.id_cliente = a.id_cliente
       WHERE a.id_animal = ?`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ erro: 'Animal não encontrado' });
    return res.json(rows[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao buscar animal', detalhe: err.message });
  }
}

// Todas as consultas de um animal específico (histórico clínico)
async function listarConsultasDoAnimal(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT co.*, v.nome AS nome_veterinario
       FROM consulta co
       JOIN veterinario v ON v.id_veterinario = co.id_veterinario
       WHERE co.id_animal = ?
       ORDER BY co.data_hora DESC`,
      [req.params.id]
    );
    return res.json(rows);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao listar histórico do animal', detalhe: err.message });
  }
}

async function criar(req, res) {
  try {
    const { nome, especie, raca, data_nascimento, sexo, peso, id_cliente } = req.body;
    if (!nome || !especie || !id_cliente) {
      return res.status(400).json({ erro: 'nome, especie e id_cliente são obrigatórios' });
    }

    const [clienteExiste] = await pool.query('SELECT id_cliente FROM cliente WHERE id_cliente = ?', [id_cliente]);
    if (clienteExiste.length === 0) {
      return res.status(400).json({ erro: 'id_cliente informado não existe' });
    }

    const [resultado] = await pool.query(
      `INSERT INTO animal (nome, especie, raca, data_nascimento, sexo, peso, id_cliente)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [nome, especie, raca || null, data_nascimento || null, sexo || null, peso || null, id_cliente]
    );
    const [novo] = await pool.query('SELECT * FROM animal WHERE id_animal = ?', [resultado.insertId]);
    return res.status(201).json(novo[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao criar animal', detalhe: err.message });
  }
}

async function atualizar(req, res) {
  try {
    const campos = ['nome', 'especie', 'raca', 'data_nascimento', 'sexo', 'peso', 'id_cliente'];
    const enviados = campos.filter(c => req.body[c] !== undefined);
    if (enviados.length === 0) return res.status(400).json({ erro: 'Nenhum campo válido enviado' });

    const setClause = enviados.map(c => `${c} = ?`).join(', ');
    const valores = enviados.map(c => req.body[c]);
    valores.push(req.params.id);

    const [resultado] = await pool.query(`UPDATE animal SET ${setClause} WHERE id_animal = ?`, valores);
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Animal não encontrado' });

    const [atualizado] = await pool.query('SELECT * FROM animal WHERE id_animal = ?', [req.params.id]);
    return res.json(atualizado[0]);
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao atualizar animal', detalhe: err.message });
  }
}

async function deletar(req, res) {
  try {
    // ON DELETE CASCADE em animal->cliente é o contrário do que importa aqui;
    // aqui id_animal é PAI de consulta (CASCADE), então apagar o animal
    // apaga o histórico de consultas dele. Confirmar com o usuário no front.
    const [resultado] = await pool.query('DELETE FROM animal WHERE id_animal = ?', [req.params.id]);
    if (resultado.affectedRows === 0) return res.status(404).json({ erro: 'Animal não encontrado' });
    return res.status(204).send();
  } catch (err) {
    return res.status(500).json({ erro: 'Erro ao excluir animal', detalhe: err.message });
  }
}

module.exports = { listar, buscarPorId, criar, atualizar, deletar, listarConsultasDoAnimal };
