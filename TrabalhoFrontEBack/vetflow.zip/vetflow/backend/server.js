const path = require('path');
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const pool = require('./config/db');

const authRoutes = require('./routes/authRoutes');
const animalRoutes = require('./routes/animalRoutes');
const consultaRoutes = require('./routes/consultaRoutes');
const consultaRemedioRoutes = require('./routes/consultaRemedioRoutes');
const caixaRoutes = require('./routes/caixaRoutes');
const pagamentoRoutes = require('./routes/pagamentoRoutes');
const veterinarioEspecialidadeRoutes = require('./routes/veterinarioEspecialidadeRoutes');
const {
  clienteRoutes,
  especialidadeRoutes,
  veterinarioRoutes,
  remedioRoutes
} = require('./routes/entidadesSimplesRoutes');

const app = express();

app.use(cors());
app.use(express.json());

// Logging básico de requisições em desenvolvimento (aprimoramento 6.4.b) —
// em produção fica quieto (formato 'combined' seria mais verboso do que
// precisamos pra um projeto acadêmico, então só liga no modo dev).
if ((process.env.NODE_ENV || 'development') !== 'production') {
  app.use(morgan('dev'));
}

// Rate limiting simples em /auth/login e /auth/registrar (aprimoramento 6.4.c)
// pra mitigar força bruta, coerente com o resto do cuidado com segurança do
// backend (bcrypt, whitelist de campos, queries parametrizadas).
const limitadorAuth = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 20, // 20 tentativas por IP nesse intervalo
  standardHeaders: true,
  legacyHeaders: false,
  message: { erro: 'Muitas tentativas. Aguarde alguns minutos antes de tentar novamente.' }
});

app.get('/', (req, res) => {
  res.json({ status: 'ok', servico: 'API Clínica Veterinária (VetFlow)' });
});

app.use('/auth', limitadorAuth, authRoutes);
app.use('/clientes', clienteRoutes);
app.use('/animais', animalRoutes);
app.use('/especialidades', especialidadeRoutes);
app.use('/veterinarios', veterinarioRoutes);
app.use('/veterinarios', veterinarioEspecialidadeRoutes); // /veterinarios/:id/especialidades
app.use('/remedios', remedioRoutes);
app.use('/consultas', consultaRoutes);
app.use('/prescricoes', consultaRemedioRoutes);
app.use('/caixas', caixaRoutes);
app.use('/pagamentos', pagamentoRoutes);

// Em produção, o backend também serve o build estático do frontend
// (frontend/dist), permitindo rodar o sistema inteiro num único processo
// e porta. Em desenvolvimento os dois servidores continuam separados
// (Vite em uma porta, API em outra — ver README raiz).
if (process.env.NODE_ENV === 'production') {
  const distPath = path.join(__dirname, '..', 'frontend', 'dist');
  app.use(express.static(distPath));

  // Fallback pra rotas do react-router-dom (SPA): qualquer rota que não
  // bateu em /auth, /clientes etc. e não é um arquivo estático real cai
  // aqui e recebe o index.html, deixando o roteamento por conta do React.
  app.get('*', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

// 404 pra rota de API não mapeada (só chega aqui fora do modo produção,
// já que em produção o fallback acima intercepta antes)
app.use((req, res) => {
  res.status(404).json({ erro: 'Rota não encontrada' });
});

// handler de erro genérico (evita o processo cair por exceção não tratada nas rotas)
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ erro: 'Erro interno do servidor' });
});

const PORT = process.env.PORT || 3000;

// Testa a conexão com o banco antes de subir o servidor HTTP, pra falhar
// rápido e com uma mensagem clara em vez de só aceitar requisições que
// vão quebrar em toda query (aprimoramento 6.4.g).
async function iniciar() {
  try {
    const conexao = await pool.getConnection();
    conexao.release();
    console.log('Conexão com o MySQL estabelecida com sucesso.');
  } catch (err) {
    console.error('Não foi possível conectar ao MySQL. Verifique as variáveis DB_* no .env.');
    console.error(err.message);
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`API rodando em http://localhost:${PORT}`);
  });
}

iniciar();
