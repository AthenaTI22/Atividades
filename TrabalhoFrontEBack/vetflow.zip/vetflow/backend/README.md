# API — VetFlow (backend)

Backend em Node.js + Express pro sistema de gestão da clínica veterinária.
Usa `mysql2` com pool de conexões e queries parametrizadas (**sem ORM** —
controle direto do SQL, já que o schema foi todo desenhado e auditado à
mão; ver seção "Decisões de arquitetura" abaixo).

> Este README cobre só o backend. Para configurar o projeto inteiro
> (banco + backend + frontend) do zero, veja o `README.md` na raiz do
> repositório — ele é o guia completo e único que você precisa seguir.

## Setup rápido (a partir desta pasta)

```bash
npm install
cp .env.example .env
# edite o .env com as credenciais do seu MySQL local
npm run dev   # com nodemon, reinicia sozinho a cada alteração
# ou
npm start     # modo produção (serve também o build do frontend, ver server.js)
```

O banco (`../database/schema.sql`) precisa já estar criado e populado
antes de subir a API — e é preciso ter pelo menos um usuário `admin` (ver
`../database/seed.sql`) pra conseguir logar.

## Autenticação

Toda rota (exceto `/auth/*`) exige header:
```
Authorization: Bearer <token>
```
O token é obtido em `POST /auth/login` e expira em 8h por padrão
(configurável via `JWT_EXPIRES_IN` no `.env`).

`tipo_usuario` controla o que cada login pode fazer:
- **admin**: acesso total
- **recepcionista**: cliente, animal, remédio, consulta (agendar), caixa, pagamento
- **veterinario**: atualizar status/diagnóstico da consulta, prescrever remédio
- **cliente**: só leitura (rotas GET)

## Endpoints principais

| Método | Rota | Descrição |
|---|---|---|
| POST | `/auth/registrar` | Cria usuário de login |
| POST | `/auth/login` | Login, retorna JWT |
| GET/POST/PUT/DELETE | `/clientes` | CRUD de clientes |
| GET/POST/PUT/DELETE | `/animais` | CRUD de animais |
| GET | `/animais/:id/consultas` | Histórico clínico do animal |
| GET/POST/PUT/DELETE | `/veterinarios` | CRUD de veterinários |
| GET/POST/DELETE | `/veterinarios/:id/especialidades` | Vincula/remove especialidade |
| GET/POST/PUT/DELETE | `/especialidades` | CRUD de especialidades |
| GET/POST/PUT/DELETE | `/remedios` | CRUD de remédios |
| GET/POST/PUT | `/consultas` | Agendar e editar consultas |
| PATCH | `/consultas/:id/status` | Muda status, registra diagnóstico/valor |
| DELETE | `/consultas/:id` | Exclui consulta (só admin) |
| POST | `/prescricoes` | Prescreve remédio (dá baixa automática no estoque) |
| DELETE | `/prescricoes/:id` | Cancela prescrição (devolve ao estoque) |
| GET | `/prescricoes/consulta/:idConsulta` | Remédios prescritos numa consulta |
| GET/POST/PATCH | `/caixas` | Lista/abre/consulta caixa |
| POST | `/caixas/abrir` | Abre caixa do dia |
| PATCH | `/caixas/:id/fechar` | Fecha caixa, calcula diferença |
| POST | `/caixas/:id/movimentacao` | Lançamento manual (entrada/saída) |
| GET/POST | `/pagamentos` | Registra pagamento de consulta |
| PATCH | `/pagamentos/:id/status` | Muda status (lança no caixa se virar "pago") |

Matriz completa de autorização por `tipo_usuario`: ver README da raiz.

## Decisões de arquitetura (pra defesa)

- **Sem ORM**: queries em SQL puro com `mysql2/promise`, parametrizadas
  (`?`) contra SQL injection. Dá mais controle e é mais fácil de justificar
  linha a linha com o que foi desenhado no schema.
- **Whitelist de campos** no CRUD genérico: nunca faz `INSERT ... SET ?`
  com `req.body` inteiro, só com os campos explicitamente esperados.
- **Transações** em prescrição de remédio e pagamento: a baixa de estoque e
  o lançamento no caixa não podem ficar "meio feitos" se o servidor cair no
  meio da operação.
- **`FOR UPDATE`** na consulta de estoque dentro da transação de prescrição:
  evita duas prescrições simultâneas venderem a última unidade do mesmo
  remédio (race condition clássica de estoque).

## Aprimoramentos adicionados na unificação (ver seção 6.4 do prompt original)

- **Log de requisições** (`morgan`, modo `dev`) — ligado só fora de
  produção, pra depuração sem poluir o log em produção.
- **Rate limiting** (`express-rate-limit`) em `/auth/login` e
  `/auth/registrar` — 20 tentativas a cada 15 min por IP, mitigando força
  bruta sem exigir infraestrutura extra (Redis etc.), coerente com o nível
  acadêmico do projeto.
- **Verificação de conexão com o banco na subida do servidor**: se o MySQL
  não estiver acessível, o processo agora falha rápido com uma mensagem
  clara em vez de aceitar requisições que vão quebrar em toda query.
- **Serving do frontend em produção**: em `NODE_ENV=production`, o Express
  passa a servir `frontend/dist` e faz fallback de rota pro `index.html`
  (necessário pro roteamento client-side do `react-router-dom` funcionar
  em URLs "profundas", tipo `/consultas/3`, quando acessadas direto).

## O que NÃO foi implementado (fora de escopo, documentado)

- Snapshot de preço em `consulta_remedio` (preço do remédio no momento da
  prescrição não é persistido na tabela, só devolvido na resposta da
  criação da prescrição — decisão original mantida).
- Hospitalização/internação.
- Refresh token (o JWT expira e exige novo login; o frontend trata isso
  redirecionando pro `/login`, ver README da raiz).
- Paginação nas listagens (assume volume pequeno de dados, uso acadêmico).
