/**
 * Cria (ou atualiza a senha de) o primeiro usuário admin do sistema.
 *
 * Não existe tela de cadastro de usuário via UI (decisão documentada nos
 * READMEs originais), então esse é um dos três caminhos oferecidos para criar
 * o primeiro acesso — os outros dois são rodar `database/seed.sql` a mão
 * com um hash já pronto, ou chamar `POST /auth/registrar` direto (curl).
 * Esse script é o mais robusto porque usa o mesmo `bcryptjs` e o mesmo
 * `config/db.js` que o resto do backend, então o hash gerado é sempre
 * compatível com o que `authController.login` espera comparar.
 *
 * Uso (a partir da pasta backend/, com o .env já configurado):
 *   node scripts/seedAdmin.js
 *   node scripts/seedAdmin.js "Outro Nome" outro@email.com outraSenha123
 *
 * Sem argumentos, usa os valores padrão abaixo (troque a senha no primeiro
 * login em produção).
 */
const bcrypt = require('bcryptjs');
const pool = require('../config/db');

const [, , nomeArg, emailArg, senhaArg] = process.argv;

const nome = nomeArg || 'Administrador VetFlow';
const email = emailArg || 'admin@vetflow.com';
const senha = senhaArg || 'admin123';

async function seedAdmin() {
  try {
    const senhaHash = await bcrypt.hash(senha, 10);

    const [existente] = await pool.query('SELECT id_usuario FROM usuario WHERE email = ?', [email]);

    if (existente.length > 0) {
      await pool.query('UPDATE usuario SET senha = ?, tipo_usuario = ? WHERE email = ?', [senhaHash, 'admin', email]);
      console.log(`Usuário admin já existia (${email}) — senha atualizada.`);
    } else {
      await pool.query(
        `INSERT INTO usuario (nome, email, senha, tipo_usuario) VALUES (?, ?, ?, 'admin')`,
        [nome, email, senhaHash]
      );
      console.log(`Usuário admin criado com sucesso.`);
    }

    console.log('---');
    console.log(`email: ${email}`);
    console.log(`senha: ${senha}`);
    console.log('---');
    console.log('Troque essa senha caso vá usar o sistema além de demonstração/apresentação.');
  } catch (err) {
    console.error('Erro ao criar/atualizar usuário admin:', err.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

seedAdmin();
