const express = require('express');
const router = express.Router();
const { autenticar, autorizar } = require('../middleware/auth');
const consultaController = require('../controllers/consultaController');

router.get('/', autenticar, consultaController.listar);
router.get('/:id', autenticar, consultaController.buscarPorId);
router.post('/', autenticar, autorizar('admin', 'recepcionista'), consultaController.criar);
router.put('/:id', autenticar, autorizar('admin', 'recepcionista'), consultaController.atualizar);
router.patch('/:id/status', autenticar, autorizar('admin', 'veterinario'), consultaController.atualizarStatus);
router.delete('/:id', autenticar, autorizar('admin'), consultaController.deletar);

module.exports = router;
