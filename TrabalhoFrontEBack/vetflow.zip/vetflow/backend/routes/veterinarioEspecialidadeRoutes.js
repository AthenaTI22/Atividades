const express = require('express');
const router = express.Router();
const { autenticar, autorizar } = require('../middleware/auth');
const veController = require('../controllers/veterinarioEspecialidadeController');

router.get('/:idVeterinario/especialidades', autenticar, veController.listarPorVeterinario);
router.post('/:idVeterinario/especialidades', autenticar, autorizar('admin'), veController.vincular);
router.delete('/:idVeterinario/especialidades/:idEspecialidade', autenticar, autorizar('admin'), veController.desvincular);

module.exports = router;
