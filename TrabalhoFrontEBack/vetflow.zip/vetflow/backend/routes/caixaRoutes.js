const express = require('express');
const router = express.Router();
const { autenticar, autorizar } = require('../middleware/auth');
const caixaController = require('../controllers/caixaController');

router.get('/', autenticar, autorizar('admin', 'recepcionista'), caixaController.listar);
router.get('/:id', autenticar, autorizar('admin', 'recepcionista'), caixaController.buscarPorId);
router.post('/abrir', autenticar, autorizar('admin', 'recepcionista'), caixaController.abrir);
router.patch('/:id/fechar', autenticar, autorizar('admin', 'recepcionista'), caixaController.fechar);
router.post('/:id/movimentacao', autenticar, autorizar('admin', 'recepcionista'), caixaController.registrarMovimentacao);

module.exports = router;
