const express = require('express');
const router = express.Router();
const { autenticar, autorizar } = require('../middleware/auth');
const consultaRemedioController = require('../controllers/consultaRemedioController');

router.get('/consulta/:idConsulta', autenticar, consultaRemedioController.listarPorConsulta);
router.post('/', autenticar, autorizar('admin', 'veterinario'), consultaRemedioController.criar);
router.delete('/:id', autenticar, autorizar('admin', 'veterinario'), consultaRemedioController.deletar);

module.exports = router;
