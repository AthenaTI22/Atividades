const express = require('express');
const router = express.Router();
const { autenticar, autorizar } = require('../middleware/auth');
const pagamentoController = require('../controllers/pagamentoController');

router.get('/', autenticar, autorizar('admin', 'recepcionista'), pagamentoController.listar);
router.get('/:id', autenticar, autorizar('admin', 'recepcionista'), pagamentoController.buscarPorId);
router.post('/', autenticar, autorizar('admin', 'recepcionista'), pagamentoController.criar);
router.patch('/:id/status', autenticar, autorizar('admin', 'recepcionista'), pagamentoController.atualizarStatus);

module.exports = router;
