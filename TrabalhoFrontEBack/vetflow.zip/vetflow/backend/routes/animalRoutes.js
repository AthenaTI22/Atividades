const express = require('express');
const router = express.Router();
const { autenticar, autorizar } = require('../middleware/auth');
const animalController = require('../controllers/animalController');

router.get('/', autenticar, animalController.listar);
router.get('/:id', autenticar, animalController.buscarPorId);
router.get('/:id/consultas', autenticar, animalController.listarConsultasDoAnimal);
router.post('/', autenticar, autorizar('admin', 'recepcionista'), animalController.criar);
router.put('/:id', autenticar, autorizar('admin', 'recepcionista'), animalController.atualizar);
router.delete('/:id', autenticar, autorizar('admin', 'recepcionista'), animalController.deletar);

module.exports = router;
