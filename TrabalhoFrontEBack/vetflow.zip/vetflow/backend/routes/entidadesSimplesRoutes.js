const express = require('express');
const { autenticar, autorizar } = require('../middleware/auth');
const {
  clienteController,
  especialidadeController,
  veterinarioController,
  remedioController
} = require('../controllers/entidadesSimples');

function rotasCrud(controller, opcoesEscrita = []) {
  const router = express.Router();
  router.get('/', autenticar, controller.listar);
  router.get('/:id', autenticar, controller.buscarPorId);
  router.post('/', autenticar, autorizar(...opcoesEscrita), controller.criar);
  router.put('/:id', autenticar, autorizar(...opcoesEscrita), controller.atualizar);
  router.delete('/:id', autenticar, autorizar(...opcoesEscrita), controller.deletar);
  return router;
}

// Quem pode criar/editar/excluir cada entidade
const clienteRoutes = rotasCrud(clienteController, ['admin', 'recepcionista']);
const especialidadeRoutes = rotasCrud(especialidadeController, ['admin']);
const veterinarioRoutes = rotasCrud(veterinarioController, ['admin']);
const remedioRoutes = rotasCrud(remedioController, ['admin', 'recepcionista']);

module.exports = { clienteRoutes, especialidadeRoutes, veterinarioRoutes, remedioRoutes };
