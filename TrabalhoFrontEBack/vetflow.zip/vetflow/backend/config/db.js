const mysql = require('mysql2/promise');
require('dotenv').config();

// Pool de conexões: reaproveita conexões em vez de abrir uma nova a cada
// query, o que é essencial numa API que vai levar várias requisições
// simultâneas (ex: recepção abrindo consulta enquanto o financeiro fecha caixa).
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  dateStrings: true // evita o driver converter DATETIME/DATE em objetos Date com timezone
});

module.exports = pool;
