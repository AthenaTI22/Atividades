const jwt = require('jsonwebtoken');
require('dotenv').config();

// Verifica se o token JWT é válido e injeta os dados do usuário em req.usuario
function autenticar(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // formato: "Bearer <token>"

  if (!token) {
    return res.status(401).json({ erro: 'Token não fornecido' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, payload) => {
    if (err) {
      return res.status(403).json({ erro: 'Token inválido ou expirado' });
    }
    req.usuario = payload; // { id_usuario, tipo_usuario, id_cliente, id_veterinario }
    next();
  });
}

// Restringe uma rota a determinados tipos de usuário.
// Uso: autorizar('admin', 'recepcionista')
function autorizar(...tiposPermitidos) {
  return (req, res, next) => {
    if (!req.usuario) {
      return res.status(401).json({ erro: 'Não autenticado' });
    }
    if (!tiposPermitidos.includes(req.usuario.tipo_usuario)) {
      return res.status(403).json({ erro: 'Sem permissão para acessar este recurso' });
    }
    next();
  };
}

module.exports = { autenticar, autorizar };
