public class Gerente extends Funcionario {
    private String departamento;
    private double bonus;

    public Gerente(String nome, String cpf, double salario, String departamento, double bonus) {
        super(nome, cpf, salario);
        this.departamento = departamento;
        this.bonus = bonus;
    }

    public Gerente(int i, String departamento, double bonus, String s, String string, String s1) {
        super(1, "Maria", 35, "F");
        this.departamento = departamento;
        this.bonus = bonus;
    }

    public Gerente(int i, String departamento, int bonus, String s, String string, String s1) {
        super(1, "Maria", 35, "F");
        this.departamento = departamento;
        this.bonus = bonus;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
}
