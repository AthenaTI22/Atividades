void main (){

    Funcionario f1 = new Funcionario("Maria", "111.222.333-44", 3500.00);

    Gerente gerente = new Gerente("Joao\n", "12345678910\n", 4500.00, "TI", 1010.00);
    System.out.println("Gerente: " + gerente);
}